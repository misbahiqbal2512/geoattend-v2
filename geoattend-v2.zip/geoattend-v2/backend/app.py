import logging
import os
from datetime import datetime, timezone

from flask import Flask, jsonify, render_template, request
from flask_socketio import SocketIO, emit, join_room, leave_room

from routes.admin import admin_bp
from routes.attendance import attendance_bp
from routes.auth import auth_bp
from routes.frontend import frontend_bp
from routes.student import student_bp
from routes.teacher import teacher_bp

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

socketio = SocketIO()


def _pick_async_mode() -> str:
    """
    Prefer eventlet (used in production via gunicorn -k eventlet), but fall
    back to 'threading' if eventlet isn't installed or is broken on this
    platform (common on some Windows + Python 3.12 setups). 'threading'
    works everywhere for local development.
    """
    override = os.getenv("SOCKETIO_ASYNC_MODE")
    if override:
        return override
    try:
        import eventlet  # noqa: F401
        return "eventlet"
    except ImportError:
        return "threading"


def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")

    from dotenv import load_dotenv
    load_dotenv()

    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret-change-in-production")
    app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "dev-jwt-secret-change-in-production")

    # CORS
    @app.after_request
    def add_cors(response):
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
        return response

    @app.before_request
    def handle_preflight():
        if request.method == "OPTIONS":
            return jsonify({}), 200

    # Blueprints
    app.register_blueprint(frontend_bp)
    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(student_bp, url_prefix="/api/student")
    app.register_blueprint(teacher_bp, url_prefix="/api/teacher")
    app.register_blueprint(admin_bp, url_prefix="/api/admin")
    app.register_blueprint(attendance_bp, url_prefix="/api/attendance")

    # Error handlers
    @app.errorhandler(404)
    def not_found(_):
        if request.path.startswith("/api/"):
            return jsonify({"error": "NotFound", "message": "Endpoint not found"}), 404
        return render_template("404.html"), 404

    @app.errorhandler(405)
    def method_not_allowed(_):
        return jsonify({"error": "MethodNotAllowed", "message": "Method not allowed"}), 405

    @app.errorhandler(500)
    def server_error(e):
        app.logger.exception("Unhandled exception")
        return jsonify({"error": "ServerError", "message": "Internal server error"}), 500

    # Initialize SocketIO
    socketio.init_app(app, cors_allowed_origins="*", async_mode=_pick_async_mode(), logger=False, engineio_logger=False)
    _register_socket_events()

    return app


def _register_socket_events():
    from auth import decode_token

    @socketio.on("connect")
    def on_connect():
        token = request.args.get("token")
        if not token:
            return False  # reject
        payload = decode_token(token)
        if not payload:
            return False
        # join personal room
        join_room(f"user_{payload['sub']}")
        join_room(f"role_{payload['role']}")

    @socketio.on("join_session")
    def on_join_session(data):
        session_id = data.get("session_id")
        if session_id:
            join_room(f"session_{session_id}")

    @socketio.on("leave_session")
    def on_leave_session(data):
        session_id = data.get("session_id")
        if session_id:
            leave_room(f"session_{session_id}")

    @socketio.on("location_update")
    def on_location_update(data):
        """Student sends location; server checks geofence and marks attendance."""
        token = request.args.get("token")
        if not token:
            return
        from auth import decode_token as _decode
        payload = _decode(token)
        if not payload or payload.get("role") != "student":
            return

        from attendance_engine import process_location_update
        process_location_update(
            student_id=int(payload["sub"]),
            lat=float(data.get("lat", 0)),
            lon=float(data.get("lon", 0)),
            accuracy=float(data.get("accuracy", 999)),
            socketio=socketio,
        )


if __name__ == "__main__":
    app = create_app()
    socketio.run(app, debug=True, port=5000, host="0.0.0.0")
