import re
from flask import request


def json_body(required_fields: list[str]) -> tuple[dict, dict | None]:
    """
    Parse JSON body and validate required fields.
    Returns (data, error_dict).  error_dict is None on success.
    """
    data = request.get_json(silent=True, force=True)
    if not isinstance(data, dict):
        data = {}

    missing = [f for f in required_fields if not str(data.get(f, "")).strip()]
    if missing:
        return {}, {
            "error": "ValidationError",
            "message": f"Missing or empty fields: {', '.join(missing)}",
            "missing_fields": missing,
        }
    return data, None


def is_valid_email(email: str) -> bool:
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email.strip()))


def validate_password(password: str) -> str | None:
    """Return an error message string, or None if valid."""
    if len(password) < 8:
        return "Password must be at least 8 characters"
    if not re.search(r"[A-Z]", password):
        return "Password must contain at least one uppercase letter"
    if not re.search(r"[0-9]", password):
        return "Password must contain at least one number"
    return None
