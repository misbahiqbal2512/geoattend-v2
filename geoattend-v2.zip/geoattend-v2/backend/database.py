"""
JSON file-based database layer with thread safety.
"""
import json
import threading
from datetime import datetime
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)

_locks: dict[str, threading.Lock] = {}


def _lock_for(name: str) -> threading.Lock:
    if name not in _locks:
        _locks[name] = threading.Lock()
    return _locks[name]


def _path(name: str) -> Path:
    return DATA_DIR / f"{name}.json"


def _load(name: str) -> list[dict]:
    p = _path(name)
    if not p.exists():
        p.write_text("[]", encoding="utf-8")
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []


def _save(name: str, records: list[dict]) -> None:
    _path(name).write_text(
        json.dumps(records, indent=2, default=str, ensure_ascii=False),
        encoding="utf-8",
    )


def get_all(table: str) -> list[dict]:
    with _lock_for(table):
        return list(_load(table))


def get_by_id(table: str, record_id: int) -> dict | None:
    with _lock_for(table):
        return next((r for r in _load(table) if r.get("id") == record_id), None)


def find_one(table: str, **kwargs) -> dict | None:
    with _lock_for(table):
        for record in _load(table):
            if all(str(record.get(k, "")).lower() == str(v).lower() for k, v in kwargs.items()):
                return record
        return None


def find_many(table: str, **kwargs) -> list[dict]:
    with _lock_for(table):
        result = []
        for record in _load(table):
            if all(record.get(k) == v for k, v in kwargs.items()):
                result.append(record)
        return result


def insert(table: str, record: dict) -> dict:
    with _lock_for(table):
        records = _load(table)
        new_id = max((r.get("id", 0) for r in records), default=0) + 1
        record = {"id": new_id, "created_at": datetime.utcnow().isoformat(), **record}
        records.append(record)
        _save(table, records)
        return record


def update(table: str, record_id: int, changes: dict) -> dict | None:
    with _lock_for(table):
        records = _load(table)
        for i, r in enumerate(records):
            if r.get("id") == record_id:
                records[i] = {**r, **changes, "updated_at": datetime.utcnow().isoformat()}
                _save(table, records)
                return records[i]
        return None


def delete(table: str, record_id: int) -> bool:
    with _lock_for(table):
        records = _load(table)
        new_records = [r for r in records if r.get("id") != record_id]
        if len(new_records) == len(records):
            return False
        _save(table, new_records)
        return True


def count(table: str) -> int:
    with _lock_for(table):
        return len(_load(table))


def exists(table: str, **kwargs) -> bool:
    return find_one(table, **kwargs) is not None
