/* ============================================================
   GeoAttend — Smart GPS Attendance System
   Single-Page Application with real-time Socket.IO
   ============================================================ */

const API = '';  // same origin
let token = localStorage.getItem('ga_token');
let currentUser = JSON.parse(localStorage.getItem('ga_user') || 'null');
let currentRole = localStorage.getItem('ga_role');
let socket = null;
let gpsWatchId = null;
let lastLocation = null;
let teacherMap = null, studentMap = null;
let teacherMapMarkers = {};
let classroomCircle = null;
let classroomMarker = null;
let activeSessionId = null;
let attendanceChartInstance = null;
let pwaInstallEvent = null;
let locationSendInterval = null;

// ─── PWA ─────────────────────────────────────────────────────────────
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  pwaInstallEvent = e;
  document.getElementById('pwa-prompt').classList.remove('hidden');
});

window.addEventListener('load', () => {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }
});

// ─── Init ─────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  setupLoginPage();
  if (token && currentUser) {
    showApp();
  }
});

// ─── Toast ────────────────────────────────────────────────────────────
function toast(msg, type = 'info', duration = 4000) {
  const icons = { success: 'fa-check-circle', error: 'fa-circle-exclamation', info: 'fa-circle-info', warning: 'fa-triangle-exclamation' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<i class="fa-solid ${icons[type] || icons.info} toast-icon"></i><span class="toast-msg">${msg}</span>`;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, duration);
}

// ─── Modal ────────────────────────────────────────────────────────────
function openModal(title, bodyHTML, footerHTML = '') {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHTML;
  document.getElementById('modal-footer').innerHTML = footerHTML;
  document.getElementById('modal-overlay').classList.remove('hidden');
}
function closeModal() { document.getElementById('modal-overlay').classList.add('hidden'); }
document.getElementById('modal-close').onclick = closeModal;
document.getElementById('modal-overlay').onclick = e => { if (e.target === document.getElementById('modal-overlay')) closeModal(); };

// ─── API Helper ───────────────────────────────────────────────────────
async function api(path, method = 'GET', body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(API + path, opts);
  const data = await res.json();
  if (!res.ok) throw { status: res.status, ...data };
  return data;
}

// ─── Login Page ───────────────────────────────────────────────────────
function setupLoginPage() {
  let selectedRole = 'student';

  document.querySelectorAll('.role-tab').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('.role-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedRole = btn.dataset.role;
    };
  });

  document.querySelectorAll('.demo-chip').forEach(chip => {
    chip.onclick = () => {
      document.getElementById('login-email').value = chip.dataset.email;
      document.getElementById('login-password').value = chip.dataset.pw;
      const role = chip.dataset.role;
      document.querySelectorAll('.role-tab').forEach(b => {
        b.classList.toggle('active', b.dataset.role === role);
      });
      selectedRole = role;
    };
  });

  document.getElementById('toggle-pw').onclick = () => {
    const inp = document.getElementById('login-password');
    inp.type = inp.type === 'password' ? 'text' : 'password';
  };

  document.getElementById('pwa-install-btn').onclick = async () => {
    if (pwaInstallEvent) { pwaInstallEvent.prompt(); }
  };
  document.getElementById('pwa-dismiss-btn').onclick = () => {
    document.getElementById('pwa-prompt').classList.add('hidden');
  };

  document.getElementById('login-form').onsubmit = async e => {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    const errEl = document.getElementById('login-error');
    const btn = document.getElementById('login-btn');

    errEl.classList.add('hidden');
    btn.querySelector('.btn-text').classList.add('hidden');
    btn.querySelector('.btn-loader').classList.remove('hidden');
    btn.disabled = true;

    try {
      const data = await api('/api/auth/login', 'POST', { email, password, role: selectedRole });
      token = data.access_token;
      currentUser = data.user;
      currentRole = data.role;
      localStorage.setItem('ga_token', token);
      localStorage.setItem('ga_user', JSON.stringify(currentUser));
      localStorage.setItem('ga_role', currentRole);
      showApp();
    } catch (err) {
      errEl.textContent = err.message || 'Login failed. Please try again.';
      errEl.classList.remove('hidden');
    } finally {
      btn.querySelector('.btn-text').classList.remove('hidden');
      btn.querySelector('.btn-loader').classList.add('hidden');
      btn.disabled = false;
    }
  };
}

// ─── Show App ─────────────────────────────────────────────────────────
function showApp() {
  document.getElementById('page-login').classList.remove('active');
  document.getElementById('page-app').classList.add('active');
  document.getElementById('page-app').style.display = 'flex';

  // User info in sidebar
  const name = currentUser?.name || 'User';
  const initials = name.split(' ').map(n => n[0]).join('').slice(0, 2);
  document.getElementById('user-avatar-mini').textContent = initials;
  document.getElementById('user-name-mini').textContent = name;
  document.getElementById('user-role-mini').textContent = currentRole;

  buildSidebar();
  setupHamburger();
  connectSocket();

  document.getElementById('logout-btn').onclick = logout;

  // Navigate to default panel
  navigateTo(currentRole === 'admin' ? 'admin-dashboard' :
             currentRole === 'teacher' ? 'teacher-dashboard' : 'student-dashboard');

  // For students: start GPS
  if (currentRole === 'student') {
    requestGPS();
  }
}

function logout() {
  if (socket) socket.disconnect();
  if (gpsWatchId) navigator.geolocation.clearWatch(gpsWatchId);
  clearInterval(locationSendInterval);
  token = null; currentUser = null; currentRole = null;
  localStorage.removeItem('ga_token');
  localStorage.removeItem('ga_user');
  localStorage.removeItem('ga_role');
  document.getElementById('page-app').classList.remove('active');
  document.getElementById('page-app').style.display = '';
  document.getElementById('page-login').classList.add('active');
  document.querySelectorAll('.role-tab').forEach((b, i) => b.classList.toggle('active', i === 0));
  document.getElementById('main-content').innerHTML = '';
  toast('Logged out successfully', 'info');
}

// ─── Sidebar ──────────────────────────────────────────────────────────
const NAV = {
  admin: [
    { section: 'Overview', items: [
      { id: 'admin-dashboard', icon: 'fa-gauge', label: 'Dashboard' },
      { id: 'admin-analytics', icon: 'fa-chart-line', label: 'Analytics' },
    ]},
    { section: 'Management', items: [
      { id: 'admin-students', icon: 'fa-users', label: 'Students' },
      { id: 'admin-teachers', icon: 'fa-chalkboard-user', label: 'Teachers' },
      { id: 'admin-attendance', icon: 'fa-clipboard-check', label: 'Attendance Records' },
    ]},
  ],
  teacher: [
    { section: 'Overview', items: [
      { id: 'teacher-dashboard', icon: 'fa-gauge', label: 'Dashboard' },
      { id: 'teacher-live', icon: 'fa-tower-broadcast', label: 'Live Session', dot: true },
    ]},
    { section: 'Management', items: [
      { id: 'teacher-courses', icon: 'fa-book', label: 'My Courses' },
      { id: 'teacher-classrooms', icon: 'fa-building', label: 'Classrooms' },
      { id: 'teacher-analytics', icon: 'fa-chart-bar', label: 'Analytics' },
    ]},
  ],
  student: [
    { section: 'My Attendance', items: [
      { id: 'student-dashboard', icon: 'fa-gauge', label: 'Dashboard' },
      { id: 'student-history', icon: 'fa-clock-rotate-left', label: 'Attendance History' },
      { id: 'student-courses', icon: 'fa-book', label: 'My Courses' },
    ]},
    { section: 'Account', items: [
      { id: 'student-profile', icon: 'fa-circle-user', label: 'Profile' },
    ]},
  ],
};

function buildSidebar() {
  const nav = document.getElementById('sidebar-nav');
  nav.innerHTML = '';
  const sections = NAV[currentRole] || [];
  sections.forEach(sec => {
    const secEl = document.createElement('div');
    secEl.className = 'nav-section';
    secEl.innerHTML = `<div class="nav-section-title">${sec.section}</div>`;
    sec.items.forEach(item => {
      const btn = document.createElement('button');
      btn.className = 'nav-item';
      btn.dataset.panel = item.id;
      btn.innerHTML = `<i class="fa-solid ${item.icon}"></i>${item.label}${item.dot ? '<span class="session-dot hidden" id="session-dot"></span>' : ''}`;
      btn.onclick = () => { navigateTo(item.id); closeSidebar(); };
      secEl.appendChild(btn);
    });
    nav.appendChild(secEl);
  });
}

function navigateTo(panelId) {
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.panel === panelId));
  const titles = {
    'admin-dashboard': 'Dashboard', 'admin-analytics': 'Analytics', 'admin-students': 'Students',
    'admin-teachers': 'Teachers', 'admin-attendance': 'Attendance Records',
    'teacher-dashboard': 'Dashboard', 'teacher-live': 'Live Session',
    'teacher-courses': 'My Courses', 'teacher-classrooms': 'Classrooms', 'teacher-analytics': 'Analytics',
    'student-dashboard': 'Dashboard', 'student-history': 'Attendance History',
    'student-courses': 'My Courses', 'student-profile': 'My Profile',
  };
  document.getElementById('topbar-title').textContent = titles[panelId] || 'GeoAttend';
  renderPanel(panelId);
}

function setupHamburger() {
  document.getElementById('hamburger').onclick = () => {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebar-overlay').classList.toggle('hidden');
  };
  document.getElementById('sidebar-overlay').onclick = closeSidebar;
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebar-overlay').classList.add('hidden');
}

// ─── Socket.IO ────────────────────────────────────────────────────────
function connectSocket() {
  if (!token) return;
  socket = io({ auth: { token }, query: { token }, transports: ['websocket', 'polling'] });

  socket.on('connect', () => console.log('Socket connected'));
  socket.on('disconnect', () => console.log('Socket disconnected'));

  // Teacher: live attendance events
  socket.on('attendance_marked', data => {
    updateLiveFeed(data);
    toast(`✓ ${data.student_name} marked ${data.status.toUpperCase()}`, 'success');
    if (teacherMap) updateStudentMapMarker(data, true);
  });

  socket.on('student_location', data => {
    if (teacherMap) updateStudentMapMarker(data, data.inside);
  });

  // Student: confirmation
  socket.on('attendance_confirmed', data => {
    const statusColors = { present: 'success', late: 'warning', absent: 'error' };
    toast(`🎯 ${data.message}`, statusColors[data.status] || 'info', 6000);
    updateGpsIndicator('marked', `Marked ${data.status}`);
    refreshStudentDashboard();
  });
}

function joinSessionRoom(sessionId) {
  if (socket && sessionId) {
    socket.emit('join_session', { session_id: sessionId });
    activeSessionId = sessionId;
  }
}

function leaveSessionRoom(sessionId) {
  if (socket && sessionId) {
    socket.emit('leave_session', { session_id: sessionId });
    activeSessionId = null;
  }
}

// ─── GPS ──────────────────────────────────────────────────────────────
function requestGPS() {
  if (!navigator.geolocation) {
    updateGpsIndicator('error', 'GPS not supported');
    return;
  }
  navigator.geolocation.getCurrentPosition(
    pos => {
      lastLocation = pos;
      updateGpsIndicator('active', `GPS Active`);
      startLocationTracking();
    },
    err => {
      updateGpsIndicator('error', 'GPS denied');
      toast('Location access denied. Attendance cannot be tracked automatically.', 'warning', 6000);
    },
    { enableHighAccuracy: true, timeout: 10000 }
  );
}

function startLocationTracking() {
  if (gpsWatchId) navigator.geolocation.clearWatch(gpsWatchId);
  gpsWatchId = navigator.geolocation.watchPosition(
    pos => {
      lastLocation = pos;
      sendLocationIfSessionActive(pos);
    },
    () => {},
    { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 }
  );

  // Also send on interval as backup
  clearInterval(locationSendInterval);
  locationSendInterval = setInterval(() => {
    if (lastLocation) sendLocationIfSessionActive(lastLocation);
  }, 10000);
}

function sendLocationIfSessionActive(pos) {
  if (!socket || !socket.connected) return;
  socket.emit('location_update', {
    lat: pos.coords.latitude,
    lon: pos.coords.longitude,
    accuracy: pos.coords.accuracy,
  });
}

function updateGpsIndicator(state, text) {
  const el = document.getElementById('gps-indicator');
  el.className = 'gps-indicator';
  if (state === 'active' || state === 'tracking') el.classList.add('active');
  if (state === 'tracking') el.classList.add('tracking');
  if (state === 'marked') el.classList.add('active');
  document.getElementById('gps-status-text').textContent = text || 'GPS';
}

// ─── Panel Router ─────────────────────────────────────────────────────
function renderPanel(id) {
  const mc = document.getElementById('main-content');
  mc.innerHTML = '<div class="empty-state"><i class="fa-solid fa-spinner fa-spin" style="font-size:2rem;color:var(--primary)"></i></div>';
  const map = {
    'admin-dashboard': renderAdminDashboard,
    'admin-analytics': renderAdminAnalytics,
    'admin-students': renderAdminStudents,
    'admin-teachers': renderAdminTeachers,
    'admin-attendance': renderAdminAttendance,
    'teacher-dashboard': renderTeacherDashboard,
    'teacher-live': renderTeacherLive,
    'teacher-courses': renderTeacherCourses,
    'teacher-classrooms': renderTeacherClassrooms,
    'teacher-analytics': renderTeacherAnalytics,
    'student-dashboard': renderStudentDashboard,
    'student-history': renderStudentHistory,
    'student-courses': renderStudentCourses,
    'student-profile': renderStudentProfile,
  };
  if (map[id]) map[id]();
}

// ═══════════════════════════════════════════════════════════════════════
// ADMIN PANELS
// ═══════════════════════════════════════════════════════════════════════

async function renderAdminDashboard() {
  try {
    const [dash, analytics] = await Promise.all([
      api('/api/admin/dashboard'),
      api('/api/attendance/analytics/admin'),
    ]);
    document.getElementById('main-content').innerHTML = `
    <div class="page-header">
      <h2>Admin Dashboard</h2>
      <p>Overview of the GeoAttend system</p>
    </div>
    <div class="stats-grid">
      <div class="stat-card indigo"><div class="stat-icon"><i class="fa-solid fa-users"></i></div><div class="stat-value">${dash.students}</div><div class="stat-label">Total Students</div></div>
      <div class="stat-card violet"><div class="stat-icon"><i class="fa-solid fa-chalkboard-user"></i></div><div class="stat-value">${dash.teachers}</div><div class="stat-label">Total Teachers</div></div>
      <div class="stat-card green"><div class="stat-icon"><i class="fa-solid fa-book"></i></div><div class="stat-value">${dash.courses}</div><div class="stat-label">Total Courses</div></div>
      <div class="stat-card cyan"><div class="stat-icon"><i class="fa-solid fa-building"></i></div><div class="stat-value">${dash.classrooms}</div><div class="stat-label">Classrooms</div></div>
      <div class="stat-card amber"><div class="stat-icon"><i class="fa-solid fa-tower-broadcast"></i></div><div class="stat-value">${dash.active_sessions}</div><div class="stat-label">Active Sessions</div></div>
      <div class="stat-card red"><div class="stat-icon"><i class="fa-solid fa-clipboard-check"></i></div><div class="stat-value">${dash.attendance_records}</div><div class="stat-label">Attendance Records</div></div>
    </div>
    <div class="grid-2">
      <div class="card">
        <div class="card-header"><i class="fa-solid fa-chart-pie card-icon"></i><h3>Attendance Overview</h3></div>
        <div class="card-body">
          <div class="chart-wrap"><canvas id="admin-pie-chart"></canvas></div>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><i class="fa-solid fa-percent card-icon"></i><h3>Attendance Rates</h3></div>
        <div class="card-body">
          ${renderRateBar('Present', dash.present_rate, 'green')}
          ${renderRateBar('Late', dash.late_rate, 'amber')}
          ${renderRateBar('Absent', dash.absent_rate, 'red')}
        </div>
      </div>
    </div>`;
    renderPieChart('admin-pie-chart', [analytics.present, analytics.late, analytics.absent]);
  } catch(e) { showError(e); }
}

function renderRateBar(label, pct, color) {
  return `<div style="margin-bottom:16px">
    <div style="display:flex;justify-content:space-between;margin-bottom:6px">
      <span style="font-size:.85rem;color:var(--text-muted)">${label}</span>
      <span style="font-size:.85rem;font-weight:700;color:var(--text)">${pct}%</span>
    </div>
    <div class="progress-bar-wrap"><div class="progress-bar-fill ${color}" style="width:${pct}%"></div></div>
  </div>`;
}

function renderPieChart(canvasId, [present, late, absent]) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  if (attendanceChartInstance) { attendanceChartInstance.destroy(); }
  attendanceChartInstance = new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels: ['Present', 'Late', 'Absent'],
      datasets: [{ data: [present, late, absent], backgroundColor: ['#22c55e', '#f59e0b', '#ef4444'], borderWidth: 0, hoverOffset: 8 }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom', labels: { color: '#94a3b8', padding: 16, font: { family: 'Inter', size: 13 } } } },
      cutout: '65%',
    },
  });
}

async function renderAdminAnalytics() {
  try {
    const data = await api('/api/admin/analytics');
    const stats = data.student_stats;
    document.getElementById('main-content').innerHTML = `
    <div class="page-header">
      <h2>Analytics</h2>
      <p>Student attendance performance overview</p>
    </div>
    <div class="card">
      <div class="card-header"><i class="fa-solid fa-ranking-star card-icon"></i><h3>Student Attendance Rankings</h3></div>
      <div class="card-body" style="padding:0">
        <div class="table-wrapper">
          <table>
            <thead><tr><th>#</th><th>Student</th><th>Reg No</th><th>Dept</th><th>Present</th><th>Late</th><th>Absent</th><th>Rate</th></tr></thead>
            <tbody>
              ${stats.map((s, i) => `
                <tr>
                  <td>${i + 1}</td>
                  <td class="td-primary">${s.name}</td>
                  <td>${s.reg}</td>
                  <td>${s.department}</td>
                  <td><span class="badge badge-present">${s.present}</span></td>
                  <td><span class="badge badge-late">${s.late}</span></td>
                  <td><span class="badge badge-absent">${s.absent}</span></td>
                  <td>
                    <div style="display:flex;align-items:center;gap:8px">
                      <div class="progress-bar-wrap" style="flex:1;min-width:60px"><div class="progress-bar-fill ${s.rate>=75?'green':s.rate>=50?'amber':'red'}" style="width:${s.rate}%"></div></div>
                      <span style="font-size:.85rem;font-weight:700;color:var(--text);min-width:40px">${s.rate}%</span>
                    </div>
                  </td>
                </tr>`).join('') || '<tr><td colspan="8"><div class="empty-state"><i class="fa-solid fa-inbox"></i><h4>No data yet</h4></div></td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
  } catch(e) { showError(e); }
}

async function renderAdminStudents() {
  try {
    const students = await api('/api/admin/students');
    document.getElementById('main-content').innerHTML = `
    <div class="page-header">
      <h2>Students</h2>
      <p>Manage student accounts</p>
      <div class="header-actions">
        <button class="btn btn-primary" onclick="showAddStudentModal()"><i class="fa-solid fa-plus"></i> Add Student</button>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><i class="fa-solid fa-users card-icon"></i><h3>All Students (${students.length})</h3></div>
      <div class="card-body" style="padding:0">
        <div class="table-wrapper">
          <table>
            <thead><tr><th>Name</th><th>Reg No</th><th>Email</th><th>Dept</th><th>Semester</th><th>Actions</th></tr></thead>
            <tbody>
              ${students.map(s => `
                <tr>
                  <td class="td-primary"><div style="display:flex;align-items:center;gap:10px"><div class="avatar" style="width:32px;height:32px;font-size:.7rem">${s.name.charAt(0)}</div>${s.name}</div></td>
                  <td>${s.registration_no || '—'}</td>
                  <td>${s.email}</td>
                  <td>${s.department || '—'}</td>
                  <td>${s.semester || '—'}</td>
                  <td><button class="btn btn-xs btn-danger" onclick="deleteStudent(${s.id}, '${s.name}')"><i class="fa-solid fa-trash"></i></button></td>
                </tr>`).join('') || '<tr><td colspan="6"><div class="empty-state"><i class="fa-solid fa-users"></i><h4>No students yet</h4></div></td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
  } catch(e) { showError(e); }
}

function showAddStudentModal() {
  openModal('Add New Student', `
    <div class="form-row">
      <div class="form-group-modal"><label>Full Name</label><input id="s-name" placeholder="Ali Raza"/></div>
      <div class="form-group-modal"><label>Registration No</label><input id="s-reg" placeholder="CS-2026-001"/></div>
    </div>
    <div class="form-group-modal"><label>Email</label><input id="s-email" type="email" placeholder="student@university.edu"/></div>
    <div class="form-group-modal"><label>Password</label><input id="s-pw" type="password" placeholder="Min 8 chars, 1 uppercase, 1 number"/></div>
    <div class="form-row">
      <div class="form-group-modal"><label>Department</label><input id="s-dept" placeholder="Computer Science"/></div>
      <div class="form-group-modal"><label>Semester</label><input id="s-sem" type="number" min="1" max="12" placeholder="7"/></div>
    </div>
    <div class="form-group-modal"><label>Phone (optional)</label><input id="s-phone" placeholder="+923001234567"/></div>
  `, `
    <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
    <button class="btn btn-primary" onclick="submitAddStudent()"><i class="fa-solid fa-plus"></i> Add Student</button>
  `);
}

async function submitAddStudent() {
  try {
    await api('/api/admin/students', 'POST', {
      name: document.getElementById('s-name').value,
      registration_no: document.getElementById('s-reg').value,
      email: document.getElementById('s-email').value,
      password: document.getElementById('s-pw').value,
      department: document.getElementById('s-dept').value,
      semester: document.getElementById('s-sem').value,
      phone: document.getElementById('s-phone').value,
    });
    closeModal(); toast('Student added successfully!', 'success');
    renderAdminStudents();
  } catch(e) { toast(e.message || 'Failed to add student', 'error'); }
}

async function deleteStudent(id, name) {
  if (!confirm(`Delete student "${name}"?`)) return;
  try {
    await api(`/api/admin/students/${id}`, 'DELETE');
    toast('Student deleted', 'success'); renderAdminStudents();
  } catch(e) { toast(e.message || 'Failed to delete', 'error'); }
}

async function renderAdminTeachers() {
  try {
    const teachers = await api('/api/admin/teachers');
    document.getElementById('main-content').innerHTML = `
    <div class="page-header">
      <h2>Teachers</h2>
      <div class="header-actions">
        <button class="btn btn-primary" onclick="showAddTeacherModal()"><i class="fa-solid fa-plus"></i> Add Teacher</button>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><i class="fa-solid fa-chalkboard-user card-icon"></i><h3>All Teachers (${teachers.length})</h3></div>
      <div class="card-body" style="padding:0">
        <div class="table-wrapper">
          <table>
            <thead><tr><th>Name</th><th>Employee No</th><th>Email</th><th>Department</th><th>Actions</th></tr></thead>
            <tbody>
              ${teachers.map(t => `
                <tr>
                  <td class="td-primary">${t.name}</td>
                  <td>${t.employee_no || '—'}</td>
                  <td>${t.email}</td>
                  <td>${t.department || '—'}</td>
                  <td><button class="btn btn-xs btn-danger" onclick="deleteTeacher(${t.id}, '${t.name}')"><i class="fa-solid fa-trash"></i></button></td>
                </tr>`).join('') || '<tr><td colspan="5"><div class="empty-state"><i class="fa-solid fa-chalkboard-user"></i><h4>No teachers yet</h4></div></td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
  } catch(e) { showError(e); }
}

function showAddTeacherModal() {
  openModal('Add New Teacher', `
    <div class="form-row">
      <div class="form-group-modal"><label>Full Name</label><input id="t-name" placeholder="Dr. Ayesha Khan"/></div>
      <div class="form-group-modal"><label>Employee No</label><input id="t-empno" placeholder="T-1002"/></div>
    </div>
    <div class="form-group-modal"><label>Email</label><input id="t-email" type="email" placeholder="teacher@university.edu"/></div>
    <div class="form-group-modal"><label>Password</label><input id="t-pw" type="password" placeholder="Min 8 chars"/></div>
    <div class="form-group-modal"><label>Department</label><input id="t-dept" placeholder="Computer Science"/></div>
  `, `
    <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
    <button class="btn btn-primary" onclick="submitAddTeacher()"><i class="fa-solid fa-plus"></i> Add Teacher</button>
  `);
}

async function submitAddTeacher() {
  try {
    await api('/api/admin/teachers', 'POST', {
      name: document.getElementById('t-name').value,
      employee_no: document.getElementById('t-empno').value,
      email: document.getElementById('t-email').value,
      password: document.getElementById('t-pw').value,
      department: document.getElementById('t-dept').value,
    });
    closeModal(); toast('Teacher added!', 'success'); renderAdminTeachers();
  } catch(e) { toast(e.message || 'Failed to add teacher', 'error'); }
}

async function deleteTeacher(id, name) {
  if (!confirm(`Delete teacher "${name}"?`)) return;
  try {
    await api(`/api/admin/teachers/${id}`, 'DELETE');
    toast('Teacher deleted', 'success'); renderAdminTeachers();
  } catch(e) { toast(e.message || 'Failed to delete', 'error'); }
}

async function renderAdminAttendance() {
  try {
    const records = await api('/api/admin/attendance');
    document.getElementById('main-content').innerHTML = `
    <div class="page-header">
      <h2>Attendance Records</h2>
      <p>${records.length} total records</p>
    </div>
    <div class="card">
      <div class="card-body" style="padding:0">
        <div class="table-wrapper">
          <table>
            <thead><tr><th>Date</th><th>Student</th><th>Course</th><th>Status</th><th>Distance</th><th>Time</th><th>Del</th></tr></thead>
            <tbody>
              ${records.slice(0, 200).map(r => `
                <tr>
                  <td>${r.attendance_date || '—'}</td>
                  <td class="td-primary">${r.student_name}<br><small style="color:var(--text-dim)">${r.student_reg}</small></td>
                  <td>${r.course_code} — ${r.course_title}</td>
                  <td><span class="badge badge-${r.status}">${r.status}</span></td>
                  <td>${r.distance_meters != null ? r.distance_meters + 'm' : '—'}</td>
                  <td>${r.timestamp ? new Date(r.timestamp).toLocaleTimeString() : '—'}</td>
                  <td><button class="btn btn-xs btn-danger" onclick="deleteAttendance(${r.id})"><i class="fa-solid fa-trash"></i></button></td>
                </tr>`).join('') || '<tr><td colspan="7"><div class="empty-state"><i class="fa-solid fa-clipboard"></i><h4>No records</h4></div></td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
  } catch(e) { showError(e); }
}

async function deleteAttendance(id) {
  if (!confirm('Delete this attendance record?')) return;
  try {
    await api(`/api/admin/attendance/${id}`, 'DELETE');
    toast('Record deleted', 'success'); renderAdminAttendance();
  } catch(e) { toast(e.message || 'Failed', 'error'); }
}

// ═══════════════════════════════════════════════════════════════════════
// TEACHER PANELS
// ═══════════════════════════════════════════════════════════════════════

async function renderTeacherDashboard() {
  try {
    const dash = await api('/api/teacher/dashboard');
    document.getElementById('main-content').innerHTML = `
    <div class="page-header">
      <h2>Teacher Dashboard</h2>
      <p>Welcome back, ${currentUser?.name || 'Teacher'}</p>
    </div>
    <div class="stats-grid">
      <div class="stat-card indigo"><div class="stat-icon"><i class="fa-solid fa-book"></i></div><div class="stat-value">${dash.total_courses}</div><div class="stat-label">My Courses</div></div>
      <div class="stat-card green"><div class="stat-icon"><i class="fa-solid fa-tower-broadcast"></i></div><div class="stat-value">${dash.active_sessions.length}</div><div class="stat-label">Active Sessions</div></div>
      <div class="stat-card amber"><div class="stat-icon"><i class="fa-solid fa-calendar-check"></i></div><div class="stat-value">${dash.total_sessions_today}</div><div class="stat-label">Sessions Today</div></div>
    </div>
    ${dash.active_sessions.length ? `
    <div class="card" style="border-color:rgba(34,197,94,0.3)">
      <div class="card-header" style="background:rgba(34,197,94,0.05)"><i class="fa-solid fa-circle" style="color:var(--success);animation:pulse 1.5s ease-in-out infinite" class="card-icon"></i><h3>Active Sessions</h3></div>
      <div class="card-body" style="padding:0">
        ${dash.active_sessions.map(s => `
          <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px">
            <div style="flex:1">
              <div style="font-weight:700;color:var(--text)">${s.course?.code} — ${s.course?.title}</div>
              <div style="font-size:.82rem;color:var(--text-muted);margin-top:2px">
                <i class="fa-solid fa-building"></i> ${s.classroom?.building || '?'}, ${s.classroom?.name || '?'}
                &nbsp;•&nbsp; Started: ${new Date(s.started_at).toLocaleTimeString()}
              </div>
            </div>
            <button class="btn btn-sm btn-success" onclick="navigateTo('teacher-live');loadLiveSession(${s.id})">
              <i class="fa-solid fa-eye"></i> View Live
            </button>
          </div>`).join('')}
      </div>
    </div>` : ''}
    <div class="card">
      <div class="card-header"><i class="fa-solid fa-book card-icon"></i><h3>My Courses</h3></div>
      <div class="card-body" style="padding:0">
        ${dash.courses.length ? dash.courses.map(c => `
          <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px">
            <div style="width:40px;height:40px;background:linear-gradient(135deg,var(--primary),var(--secondary));border-radius:10px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:.8rem;font-weight:700;flex-shrink:0">${c.code?.slice(-3)}</div>
            <div style="flex:1">
              <div style="font-weight:700;color:var(--text)">${c.code} — ${c.title}</div>
              <div style="font-size:.8rem;color:var(--text-muted)">${c.schedule_day} ${c.start_time}–${c.end_time} &nbsp;•&nbsp; ${c.enrolled_count} students &nbsp;•&nbsp; ${c.classroom?.name || 'No room'}</div>
            </div>
            <button class="btn btn-sm btn-primary" onclick="startSessionForCourse(${c.id}, '${c.code}')">
              <i class="fa-solid fa-play"></i> Start
            </button>
          </div>`).join('') : '<div class="empty-state"><i class="fa-solid fa-book"></i><h4>No courses yet</h4><p>Create a course to get started</p></div>'}
      </div>
    </div>`;
  } catch(e) { showError(e); }
}

async function startSessionForCourse(courseId, courseCode) {
  try {
    const data = await api('/api/teacher/sessions/start', 'POST', { course_id: courseId });
    toast(`Session started for ${courseCode}!`, 'success');
    const dot = document.getElementById('session-dot');
    if (dot) dot.classList.remove('hidden');
    navigateTo('teacher-live');
    loadLiveSession(data.session.id);
  } catch(e) {
    if (e.session) {
      toast(`Session already active! Loading...`, 'info');
      navigateTo('teacher-live');
      loadLiveSession(e.session.id);
    } else {
      toast(e.message || 'Failed to start session', 'error');
    }
  }
}

let liveRefreshInterval = null;
async function renderTeacherLive() {
  clearInterval(liveRefreshInterval);
  try {
    const sessions = await api('/api/teacher/sessions');
    const active = sessions.filter(s => s.status === 'active');
    if (!active.length) {
      document.getElementById('main-content').innerHTML = `
      <div class="page-header"><h2>Live Session Monitor</h2></div>
      <div class="empty-state">
        <i class="fa-solid fa-tower-broadcast"></i>
        <h4>No Active Session</h4>
        <p>Start a session from your dashboard or courses page</p>
        <button class="btn btn-primary" style="margin-top:16px" onclick="navigateTo('teacher-dashboard')"><i class="fa-solid fa-arrow-left"></i> Go to Dashboard</button>
      </div>`;
      return;
    }
    await loadLiveSession(active[0].id);
  } catch(e) { showError(e); }
}

async function loadLiveSession(sessionId) {
  clearInterval(liveRefreshInterval);
  joinSessionRoom(sessionId);

  const renderLive = async () => {
    try {
      const live = await api(`/api/teacher/sessions/${sessionId}/live`);
      renderLiveSessionUI(live, sessionId);
    } catch(e) {}
  };

  await renderLive();
  liveRefreshInterval = setInterval(renderLive, 15000); // Refresh every 15s as backup
}

function renderLiveSessionUI(live, sessionId) {
  const { session, present, late, absent, waiting, counts, live_locations } = live;
  const mc = document.getElementById('main-content');
  mc.innerHTML = `
  <div class="page-header">
    <h2>Live Session Monitor</h2>
    <p>${session.course?.code} — ${session.course?.title}</p>
  </div>
  <div class="session-banner">
    <div class="pulse-dot"></div>
    <div class="session-banner-info">
      <h4>Session Active — ${session.classroom?.building}, ${session.classroom?.name}</h4>
      <p>Started: ${new Date(session.started_at).toLocaleTimeString()} &nbsp;•&nbsp; Radius: ${session.classroom?.radius_meters}m</p>
    </div>
    <button class="btn btn-danger btn-sm" onclick="endSession(${sessionId})"><i class="fa-solid fa-stop"></i> End Session</button>
  </div>
  <div class="stats-grid" style="grid-template-columns:repeat(4,1fr)">
    <div class="stat-card green"><div class="stat-icon"><i class="fa-solid fa-circle-check"></i></div><div class="stat-value">${counts.present}</div><div class="stat-label">Present</div></div>
    <div class="stat-card amber"><div class="stat-icon"><i class="fa-solid fa-clock"></i></div><div class="stat-value">${counts.late}</div><div class="stat-label">Late</div></div>
    <div class="stat-card red"><div class="stat-icon"><i class="fa-solid fa-circle-xmark"></i></div><div class="stat-value">${counts.absent}</div><div class="stat-label">Absent</div></div>
    <div class="stat-card indigo"><div class="stat-icon"><i class="fa-solid fa-hourglass-half"></i></div><div class="stat-value">${counts.waiting}</div><div class="stat-label">Waiting</div></div>
  </div>
  <div class="grid-2">
    <div>
      <div class="card">
        <div class="card-header"><i class="fa-solid fa-rss card-icon"></i><h3>Live Attendance Feed</h3></div>
        <div class="card-body">
          <div class="live-feed" id="live-feed">
            ${[...present, ...late].sort((a,b) => (b.timestamp||'').localeCompare(a.timestamp||'')).map(s => `
              <div class="feed-item">
                <div class="feed-dot ${s.status}"></div>
                <div>
                  <div class="feed-name">${s.name}</div>
                  <div class="feed-meta">${s.reg} &nbsp;•&nbsp; ${s.distance}m from classroom</div>
                </div>
                <div class="feed-time">${s.timestamp ? new Date(s.timestamp).toLocaleTimeString() : ''}</div>
                <span class="badge badge-${s.status}">${s.status}</span>
              </div>`).join('') || '<div class="empty-state" style="padding:20px"><i class="fa-solid fa-hourglass"></i><h4>Waiting for students...</h4></div>'}
          </div>
          ${waiting.length ? `
          <div style="margin-top:16px">
            <div style="font-size:.78rem;color:var(--text-dim);margin-bottom:8px;text-transform:uppercase;letter-spacing:.5px">Waiting (${waiting.length})</div>
            <div class="waiting-list" id="waiting-list">
              ${waiting.map(s => `<div class="waiting-chip"><i class="fa-solid fa-clock"></i>${s.name}</div>`).join('')}
            </div>
          </div>` : ''}
        </div>
      </div>
    </div>
    <div>
      <div class="card">
        <div class="card-header"><i class="fa-solid fa-map card-icon"></i><h3>Live Classroom Map</h3></div>
        <div class="card-body" style="padding:12px">
          <div class="map-container"><div id="teacher-map"></div></div>
          <div class="map-legend">
            <div class="legend-item"><div class="legend-dot classroom"></div> Classroom</div>
            <div class="legend-item"><div class="legend-dot inside"></div> Inside radius</div>
            <div class="legend-item"><div class="legend-dot outside"></div> Outside radius</div>
          </div>
        </div>
      </div>
    </div>
  </div>`;

  // Init map
  setTimeout(() => initTeacherMap(session, live_locations, [...present, ...late, ...absent]), 200);
}

function initTeacherMap(session, live_locations, marked_students) {
  const lat = session.classroom?.latitude || 31.5204;
  const lon = session.classroom?.longitude || 74.3587;
  const radius = session.classroom?.radius_meters || 50;

  if (teacherMap) { teacherMap.remove(); teacherMap = null; }
  teacherMapMarkers = {};

  teacherMap = L.map('teacher-map', { zoomControl: true }).setView([lat, lon], 18);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap'
  }).addTo(teacherMap);

  // Classroom circle
  classroomCircle = L.circle([lat, lon], {
    radius, color: '#6366f1', fillColor: '#6366f1', fillOpacity: 0.1, weight: 2
  }).addTo(teacherMap);

  // Classroom marker
  const classIcon = L.divIcon({
    html: '<div style="background:#6366f1;width:16px;height:16px;border-radius:50%;border:3px solid #fff;box-shadow:0 2px 8px rgba(99,102,241,0.6)"></div>',
    className: '', iconAnchor: [8, 8]
  });
  L.marker([lat, lon], { icon: classIcon }).addTo(teacherMap).bindPopup(`<b>${session.classroom?.name}</b><br>${session.classroom?.building}`);

  // Live student locations on map
  live_locations.forEach(loc => {
    addStudentMarker(loc.student_id, loc.lat, loc.lon, loc.inside_status === 'inside', null, loc.session_id);
  });
}

function addStudentMarker(studentId, lat, lon, inside, name, sessionId) {
  if (!teacherMap) return;
  const color = inside ? '#22c55e' : '#ef4444';
  const icon = L.divIcon({
    html: `<div style="background:${color};width:12px;height:12px;border-radius:50%;border:2px solid #fff;box-shadow:0 2px 6px ${color}66"></div>`,
    className: '', iconAnchor: [6, 6]
  });
  if (teacherMapMarkers[studentId]) {
    teacherMapMarkers[studentId].setLatLng([lat, lon]);
  } else {
    teacherMapMarkers[studentId] = L.marker([lat, lon], { icon }).addTo(teacherMap);
    if (name) teacherMapMarkers[studentId].bindPopup(name);
  }
}

function updateStudentMapMarker(data, inside) {
  addStudentMarker(data.student_id, data.lat, data.lon, inside, data.student_name);
}

function updateLiveFeed(data) {
  const feed = document.getElementById('live-feed');
  if (!feed) return;
  const item = document.createElement('div');
  item.className = 'feed-item';
  item.innerHTML = `
    <div class="feed-dot ${data.status}"></div>
    <div>
      <div class="feed-name">${data.student_name}</div>
      <div class="feed-meta">${data.student_reg} &nbsp;•&nbsp; ${data.distance}m away</div>
    </div>
    <div class="feed-time">${new Date(data.timestamp).toLocaleTimeString()}</div>
    <span class="badge badge-${data.status}">${data.status}</span>`;
  feed.insertBefore(item, feed.firstChild);

  // Remove from waiting
  const waiting = document.getElementById('waiting-list');
  if (waiting) {
    const chips = waiting.querySelectorAll('.waiting-chip');
    chips.forEach(chip => { if (chip.textContent.includes(data.student_name)) chip.remove(); });
  }
}

async function endSession(sessionId) {
  if (!confirm('End this attendance session? All remaining students will be marked absent.')) return;
  try {
    await api(`/api/teacher/sessions/${sessionId}/end`, 'POST');
    leaveSessionRoom(sessionId);
    clearInterval(liveRefreshInterval);
    const dot = document.getElementById('session-dot');
    if (dot) dot.classList.add('hidden');
    toast('Session ended successfully', 'success');
    renderTeacherDashboard();
  } catch(e) { toast(e.message || 'Failed to end session', 'error'); }
}

async function renderTeacherCourses() {
  try {
    const [dash, classrooms, students] = await Promise.all([
      api('/api/teacher/dashboard'),
      api('/api/teacher/classrooms'),
      api('/api/admin/students'),
    ]);
    document.getElementById('main-content').innerHTML = `
    <div class="page-header">
      <h2>My Courses</h2>
      <div class="header-actions">
        <button class="btn btn-primary" onclick="showCreateCourseModal(${JSON.stringify(classrooms).replace(/"/g, '&quot;')})">
          <i class="fa-solid fa-plus"></i> New Course
        </button>
      </div>
    </div>
    <div class="card">
      <div class="card-body" style="padding:0">
        ${dash.courses.length ? dash.courses.map(c => `
          <div style="padding:18px 20px;border-bottom:1px solid var(--border)">
            <div style="display:flex;align-items:flex-start;gap:12px">
              <div style="width:44px;height:44px;background:linear-gradient(135deg,var(--primary),var(--secondary));border-radius:12px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:.75rem;font-weight:700;flex-shrink:0">${c.code?.slice(-3)}</div>
              <div style="flex:1">
                <div style="font-weight:700;font-size:1rem;color:var(--text)">${c.code} — ${c.title}</div>
                <div style="font-size:.82rem;color:var(--text-muted);margin-top:4px">
                  <i class="fa-solid fa-calendar"></i> ${c.schedule_day} ${c.start_time}–${c.end_time}
                  &nbsp;•&nbsp; <i class="fa-solid fa-building"></i> ${c.classroom?.name || 'No room'}
                  &nbsp;•&nbsp; <i class="fa-solid fa-users"></i> ${c.enrolled_count} students
                </div>
              </div>
              <div style="display:flex;gap:8px;flex-shrink:0">
                <button class="btn btn-sm btn-primary" onclick="startSessionForCourse(${c.id}, '${c.code}')"><i class="fa-solid fa-play"></i> Start Session</button>
                <button class="btn btn-sm btn-ghost" onclick="showEnrollModal(${c.id}, '${c.code}', ${JSON.stringify(students).replace(/"/g, '&quot;')})"><i class="fa-solid fa-user-plus"></i> Enroll</button>
              </div>
            </div>
          </div>`).join('') : '<div class="empty-state"><i class="fa-solid fa-book"></i><h4>No courses yet</h4></div>'}
      </div>
    </div>`;
  } catch(e) { showError(e); }
}

function showCreateCourseModal(classrooms) {
  const opts = classrooms.map(c => `<option value="${c.id}">${c.name} (${c.building})</option>`).join('');
  const days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'].map(d => `<option>${d}</option>`).join('');
  openModal('Create New Course', `
    <div class="form-row">
      <div class="form-group-modal"><label>Course Code</label><input id="c-code" placeholder="CS-471"/></div>
      <div class="form-group-modal"><label>Title</label><input id="c-title" placeholder="Artificial Intelligence"/></div>
    </div>
    <div class="form-group-modal"><label>Classroom</label><select id="c-room">${opts || '<option>No classrooms — create one first</option>'}</select></div>
    <div class="form-row">
      <div class="form-group-modal"><label>Day</label><select id="c-day">${days}</select></div>
      <div class="form-group-modal"><label>Credit Hours</label><input id="c-credits" type="number" value="3" min="1" max="6"/></div>
    </div>
    <div class="form-row">
      <div class="form-group-modal"><label>Start Time</label><input id="c-start" type="time" value="09:00"/></div>
      <div class="form-group-modal"><label>End Time</label><input id="c-end" type="time" value="10:30"/></div>
    </div>
  `, `
    <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
    <button class="btn btn-primary" onclick="submitCreateCourse()"><i class="fa-solid fa-plus"></i> Create</button>
  `);
}

async function submitCreateCourse() {
  try {
    await api('/api/teacher/courses', 'POST', {
      code: document.getElementById('c-code').value,
      title: document.getElementById('c-title').value,
      classroom_id: document.getElementById('c-room').value,
      schedule_day: document.getElementById('c-day').value,
      start_time: document.getElementById('c-start').value,
      end_time: document.getElementById('c-end').value,
      credit_hours: document.getElementById('c-credits').value,
    });
    closeModal(); toast('Course created!', 'success'); renderTeacherCourses();
  } catch(e) { toast(e.message || 'Failed', 'error'); }
}

function showEnrollModal(courseId, courseCode, allStudents) {
  openModal(`Enroll Students — ${courseCode}`, `
    <p style="color:var(--text-muted);font-size:.88rem;margin-bottom:16px">Select a student to enroll in this course.</p>
    <div class="form-group-modal">
      <label>Student</label>
      <select id="enroll-student">
        <option value="">— Select Student —</option>
        ${allStudents.map(s => `<option value="${s.id}">${s.name} (${s.registration_no || s.email})</option>`).join('')}
      </select>
    </div>
  `, `
    <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
    <button class="btn btn-primary" onclick="submitEnroll(${courseId})"><i class="fa-solid fa-user-plus"></i> Enroll</button>
  `);
}

async function submitEnroll(courseId) {
  const sid = document.getElementById('enroll-student').value;
  if (!sid) { toast('Please select a student', 'warning'); return; }
  try {
    await api(`/api/teacher/courses/${courseId}/enroll`, 'POST', { student_id: parseInt(sid) });
    closeModal(); toast('Student enrolled!', 'success');
  } catch(e) { toast(e.message || 'Failed to enroll', 'error'); }
}

async function renderTeacherClassrooms() {
  try {
    const classrooms = await api('/api/teacher/classrooms');
    document.getElementById('main-content').innerHTML = `
    <div class="page-header">
      <h2>Classrooms</h2>
      <div class="header-actions">
        <button class="btn btn-primary" onclick="showCreateClassroomModal()"><i class="fa-solid fa-plus"></i> Add Classroom</button>
      </div>
    </div>
    <div class="grid-3">
      ${classrooms.map(c => `
        <div class="card">
          <div class="card-header"><i class="fa-solid fa-building card-icon"></i><h3>${c.name}</h3></div>
          <div class="card-body">
            <div style="font-size:.85rem;color:var(--text-muted);margin-bottom:12px">
              <div style="margin-bottom:6px"><i class="fa-solid fa-building" style="width:14px"></i> ${c.building}</div>
              <div style="margin-bottom:6px"><i class="fa-solid fa-circle-dot" style="width:14px;color:var(--success)"></i> Radius: ${c.radius_meters}m</div>
              <div style="margin-bottom:6px"><i class="fa-solid fa-location-dot" style="width:14px;color:var(--primary)"></i> ${c.latitude?.toFixed(4)}, ${c.longitude?.toFixed(4)}</div>
            </div>
            <button class="btn btn-sm btn-ghost" onclick="previewClassroomMap(${c.latitude},${c.longitude},${c.radius_meters},'${c.name}','${c.building}')">
              <i class="fa-solid fa-map"></i> View on Map
            </button>
          </div>
        </div>`).join('') || '<div class="empty-state" style="grid-column:1/-1"><i class="fa-solid fa-building"></i><h4>No classrooms yet</h4></div>'}
    </div>`;
  } catch(e) { showError(e); }
}

function previewClassroomMap(lat, lon, radius, name, building) {
  openModal(`${name} — ${building}`, `<div id="preview-map" style="height:300px;border-radius:8px;overflow:hidden"></div>`, ``);
  setTimeout(() => {
    const m = L.map('preview-map').setView([lat, lon], 18);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(m);
    L.circle([lat, lon], { radius, color: '#6366f1', fillOpacity: 0.15 }).addTo(m);
    L.marker([lat, lon]).addTo(m).bindPopup(`<b>${name}</b><br>${building}`).openPopup();
  }, 100);
}

function showCreateClassroomModal() {
  openModal('Add Classroom', `
    <div class="form-row">
      <div class="form-group-modal"><label>Room Name</label><input id="rm-name" placeholder="CS Lab 1"/></div>
      <div class="form-group-modal"><label>Building</label><input id="rm-bldg" placeholder="CS Block"/></div>
    </div>
    <div class="form-row">
      <div class="form-group-modal"><label>Latitude</label><input id="rm-lat" type="number" step="any" placeholder="31.5204"/></div>
      <div class="form-group-modal"><label>Longitude</label><input id="rm-lon" type="number" step="any" placeholder="74.3587"/></div>
    </div>
    <div class="form-group-modal"><label>Attendance Radius (meters)</label><input id="rm-radius" type="number" value="50" min="10" max="500"/></div>
    <div class="alert alert-info" style="margin-top:12px;font-size:.83rem">
      <i class="fa-solid fa-info-circle"></i> Tip: Visit the classroom physically and use your phone's GPS coordinates.
    </div>
    <button class="btn btn-ghost btn-sm" onclick="useMyLocation()" style="margin-top:8px"><i class="fa-solid fa-location-arrow"></i> Use My Current Location</button>
  `, `
    <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
    <button class="btn btn-primary" onclick="submitCreateClassroom()"><i class="fa-solid fa-plus"></i> Save</button>
  `);
}

function useMyLocation() {
  navigator.geolocation.getCurrentPosition(pos => {
    document.getElementById('rm-lat').value = pos.coords.latitude.toFixed(6);
    document.getElementById('rm-lon').value = pos.coords.longitude.toFixed(6);
    toast('Location captured!', 'success');
  }, () => toast('Could not get location', 'error'), { enableHighAccuracy: true });
}

async function submitCreateClassroom() {
  try {
    await api('/api/teacher/classrooms', 'POST', {
      name: document.getElementById('rm-name').value,
      building: document.getElementById('rm-bldg').value,
      latitude: parseFloat(document.getElementById('rm-lat').value),
      longitude: parseFloat(document.getElementById('rm-lon').value),
      radius_meters: parseFloat(document.getElementById('rm-radius').value),
    });
    closeModal(); toast('Classroom added!', 'success'); renderTeacherClassrooms();
  } catch(e) { toast(e.message || 'Failed', 'error'); }
}

async function renderTeacherAnalytics() {
  try {
    const data = await api('/api/teacher/analytics');
    document.getElementById('main-content').innerHTML = `
    <div class="page-header"><h2>Analytics</h2><p>Course attendance performance</p></div>
    <div class="grid-2">
      ${data.map(c => `
        <div class="card">
          <div class="card-header"><i class="fa-solid fa-chart-bar card-icon"></i><h3>${c.code} — ${c.title}</h3></div>
          <div class="card-body">
            <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px">
              <div style="text-align:center"><div style="font-size:1.5rem;font-weight:800;color:#86efac">${c.present}</div><div style="font-size:.75rem;color:var(--text-dim)">Present</div></div>
              <div style="text-align:center"><div style="font-size:1.5rem;font-weight:800;color:#fcd34d">${c.late}</div><div style="font-size:.75rem;color:var(--text-dim)">Late</div></div>
              <div style="text-align:center"><div style="font-size:1.5rem;font-weight:800;color:#fca5a5">${c.absent}</div><div style="font-size:.75rem;color:var(--text-dim)">Absent</div></div>
            </div>
            <div style="margin-bottom:8px;display:flex;justify-content:space-between"><span style="font-size:.85rem;color:var(--text-muted)">Attendance Rate</span><span style="font-weight:700;color:var(--text)">${c.attendance_rate}%</span></div>
            <div class="progress-bar-wrap"><div class="progress-bar-fill ${c.attendance_rate>=75?'green':c.attendance_rate>=50?'amber':'red'}" style="width:${c.attendance_rate}%"></div></div>
            <div style="font-size:.78rem;color:var(--text-dim);margin-top:8px">${c.session_count} sessions held</div>
          </div>
        </div>`).join('') || '<div class="empty-state" style="grid-column:1/-1"><i class="fa-solid fa-chart-bar"></i><h4>No data yet</h4></div>'}
    </div>`;
  } catch(e) { showError(e); }
}

// ═══════════════════════════════════════════════════════════════════════
// STUDENT PANELS
// ═══════════════════════════════════════════════════════════════════════

async function renderStudentDashboard() {
  try {
    const data = await api('/api/student/dashboard');
    const { student, analytics, active_sessions } = data;
    const pct = analytics.overall_percentage;
    const pctColor = pct >= 75 ? '#22c55e' : pct >= 50 ? '#f59e0b' : '#ef4444';
    const conicGrad = `conic-gradient(${pctColor} ${pct * 3.6}deg, var(--bg) 0deg)`;

    document.getElementById('main-content').innerHTML = `
    <div class="page-header">
      <h2>My Dashboard</h2>
      <p>Welcome back, ${student.name || 'Student'}</p>
    </div>
    ${active_sessions.length ? `
    <div class="gps-banner tracking">
      <i class="fa-solid fa-satellite-dish"></i>
      <div>
        <strong>Active Session Detected!</strong>
        Your location is being tracked for: <strong>${active_sessions.map(s => s.course?.code).join(', ')}</strong>.
        ${active_sessions.some(s => !s.already_marked) ? 'Move within the classroom radius to mark attendance automatically.' : 'Attendance already marked for today.'}
      </div>
    </div>` : `
    <div class="gps-banner waiting">
      <i class="fa-solid fa-location-dot"></i>
      <span>Waiting for an active attendance session. Your GPS is ready.</span>
    </div>`}
    <div class="grid-2">
      <div class="card">
        <div class="card-header"><i class="fa-solid fa-percent card-icon"></i><h3>Overall Attendance</h3></div>
        <div class="card-body" style="text-align:center;padding:28px">
          <div class="att-circle-lg" style="border-color:${pctColor}">
            <div class="pct-num" style="color:${pctColor}">${pct}%</div>
            <div class="pct-label">Overall</div>
          </div>
          <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);gap:8px;margin-top:16px">
            <div style="text-align:center;padding:10px;background:rgba(34,197,94,0.1);border-radius:8px">
              <div style="font-size:1.4rem;font-weight:800;color:#86efac">${analytics.present}</div>
              <div style="font-size:.73rem;color:var(--text-dim)">Present</div>
            </div>
            <div style="text-align:center;padding:10px;background:rgba(245,158,11,0.1);border-radius:8px">
              <div style="font-size:1.4rem;font-weight:800;color:#fcd34d">${analytics.late}</div>
              <div style="font-size:.73rem;color:var(--text-dim)">Late</div>
            </div>
            <div style="text-align:center;padding:10px;background:rgba(239,68,68,0.1);border-radius:8px">
              <div style="font-size:1.4rem;font-weight:800;color:#fca5a5">${analytics.absent}</div>
              <div style="font-size:.73rem;color:var(--text-dim)">Absent</div>
            </div>
          </div>
          ${pct < 75 ? '<div class="alert alert-error" style="margin-top:16px;font-size:.83rem"><i class="fa-solid fa-triangle-exclamation"></i> Below 75% threshold! Please attend more classes.</div>' : ''}
        </div>
      </div>
      <div class="card">
        <div class="card-header"><i class="fa-solid fa-clock-rotate-left card-icon"></i><h3>Recent Activity</h3></div>
        <div class="card-body" style="padding:0">
          ${analytics.recent.length ? analytics.recent.map(r => `
            <div style="padding:12px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px">
              <span class="badge badge-${r.status}">${r.status}</span>
              <div style="flex:1">
                <div style="font-size:.88rem;font-weight:600;color:var(--text)">${r.course?.code || '?'} — ${r.course?.title || '?'}</div>
                <div style="font-size:.78rem;color:var(--text-dim)">${r.attendance_date}</div>
              </div>
              ${r.distance_meters != null ? `<span style="font-size:.75rem;color:var(--text-dim)">${r.distance_meters}m</span>` : ''}
            </div>`).join('') : '<div class="empty-state" style="padding:24px"><i class="fa-solid fa-inbox"></i><h4>No records yet</h4></div>'}
        </div>
      </div>
    </div>`;
  } catch(e) { showError(e); }
}

function refreshStudentDashboard() {
  const activePanel = document.querySelector('.nav-item.active');
  if (activePanel?.dataset.panel === 'student-dashboard') renderStudentDashboard();
}

async function renderStudentHistory() {
  try {
    const records = await api('/api/attendance/history');
    document.getElementById('main-content').innerHTML = `
    <div class="page-header"><h2>Attendance History</h2><p>${records.length} records</p></div>
    <div class="card">
      <div class="card-body" style="padding:0">
        <div class="table-wrapper">
          <table>
            <thead><tr><th>Date</th><th>Course</th><th>Status</th><th>Time</th><th>Distance</th></tr></thead>
            <tbody>
              ${records.map(r => `
                <tr>
                  <td>${r.attendance_date}</td>
                  <td class="td-primary">${r.course?.code || '?'} — ${r.course?.title || '?'}</td>
                  <td><span class="badge badge-${r.status}">${r.status}</span></td>
                  <td>${r.timestamp ? new Date(r.timestamp).toLocaleTimeString() : '—'}</td>
                  <td>${r.distance_meters != null ? r.distance_meters + 'm' : '—'}</td>
                </tr>`).join('') || '<tr><td colspan="5"><div class="empty-state"><i class="fa-solid fa-inbox"></i><h4>No attendance history yet</h4></div></td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
  } catch(e) { showError(e); }
}

async function renderStudentCourses() {
  try {
    const data = await api('/api/student/dashboard');
    document.getElementById('main-content').innerHTML = `
    <div class="page-header"><h2>My Courses</h2><p>${data.courses.length} enrolled</p></div>
    <div class="grid-2">
      ${data.courses.map(c => `
        <div class="card">
          <div class="card-header"><i class="fa-solid fa-book card-icon"></i><h3>${c.code}</h3></div>
          <div class="card-body">
            <div style="font-size:1rem;font-weight:600;color:var(--text);margin-bottom:10px">${c.title}</div>
            <div style="font-size:.83rem;color:var(--text-muted);display:flex;flex-direction:column;gap:5px">
              <div><i class="fa-solid fa-calendar" style="width:14px"></i> ${c.schedule_day} ${c.start_time}–${c.end_time}</div>
              <div><i class="fa-solid fa-building" style="width:14px"></i> ${c.classroom?.building || '?'}, ${c.classroom?.name || '?'}</div>
              <div><i class="fa-solid fa-location-dot" style="width:14px;color:var(--primary)"></i> Radius: ${c.classroom?.radius_meters || '?'}m</div>
            </div>
          </div>
        </div>`).join('') || '<div class="empty-state" style="grid-column:1/-1"><i class="fa-solid fa-book"></i><h4>Not enrolled in any course</h4><p>Contact your teacher to get enrolled</p></div>'}
    </div>`;
  } catch(e) { showError(e); }
}

async function renderStudentProfile() {
  try {
    const user = await api('/api/student/profile');
    document.getElementById('main-content').innerHTML = `
    <div class="page-header"><h2>My Profile</h2></div>
    <div class="card" style="max-width:540px">
      <div class="card-body" style="text-align:center;padding:32px">
        <div class="avatar" style="width:80px;height:80px;font-size:1.8rem;margin:0 auto 16px">${user.name?.charAt(0)}</div>
        <h3 style="font-size:1.3rem;font-weight:700;margin-bottom:4px">${user.name}</h3>
        <p style="color:var(--text-muted);font-size:.88rem;margin-bottom:24px">${user.email}</p>
        <div style="text-align:left;display:grid;grid-template-columns:1fr 1fr;gap:14px">
          ${[
            ['Registration No', user.registration_no || '—'],
            ['Department', user.department || '—'],
            ['Semester', user.semester || '—'],
            ['Phone', user.phone || '—'],
            ['Role', user.role],
            ['Member Since', user.created_at?.slice(0, 10)],
          ].map(([k, v]) => `
            <div style="background:var(--bg);padding:12px;border-radius:8px">
              <div style="font-size:.73rem;color:var(--text-dim);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">${k}</div>
              <div style="font-weight:600;color:var(--text)">${v}</div>
            </div>`).join('')}
        </div>
      </div>
    </div>`;
  } catch(e) { showError(e); }
}

// ─── Helpers ──────────────────────────────────────────────────────────
function showError(e) {
  console.error(e);
  const msg = e?.message || 'An error occurred';
  document.getElementById('main-content').innerHTML = `
    <div class="empty-state">
      <i class="fa-solid fa-triangle-exclamation" style="color:var(--danger)"></i>
      <h4>${msg}</h4>
      <p>Please try refreshing the page.</p>
    </div>`;
  if (e?.status === 401) { toast('Session expired. Please log in again.', 'warning'); logout(); }
}
