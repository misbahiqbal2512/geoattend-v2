import math
from datetime import date, datetime

from flask import Blueprint, jsonify, Response

from auth import current_user_id, role_required
from database import find_many, get_by_id, get_all
from attendance_engine import haversine, compute_status

attendance_bp = Blueprint("attendance", __name__)


@attendance_bp.get("/history")
@role_required("student")
def history():
    uid = current_user_id()
    records = sorted(
        find_many("attendance", student_id=uid),
        key=lambda r: r.get("timestamp", r.get("attendance_date", "")),
        reverse=True,
    )
    result = []
    for r in records:
        course = get_by_id("courses", r["course_id"])
        result.append({**r, "course": course})
    return jsonify(result)


@attendance_bp.get("/export/csv")
@role_required("student", "teacher", "admin")
def export_csv():
    uid = current_user_id()
    records = find_many("attendance", student_id=uid)
    lines = ["date,course_id,status,distance_m,timestamp"]
    for r in records:
        lines.append(f"{r.get('attendance_date')},{r.get('course_id')},{r.get('status')},{r.get('distance_meters','')},{r.get('timestamp','')}")
    return Response(
        "\n".join(lines),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=attendance.csv"},
    )


@attendance_bp.get("/session/<int:session_id>")
@role_required("teacher", "admin")
def session_records(session_id):
    records = find_many("attendance", session_id=session_id)
    result = []
    for r in records:
        student = get_by_id("users", r["student_id"])
        result.append({**r, "student": {k: v for k, v in (student or {}).items() if k != "password_hash"}})
    return jsonify(result)


@attendance_bp.get("/analytics/admin")
@role_required("admin")
def admin_analytics():
    records = get_all("attendance")
    total = len(records)
    present = sum(1 for r in records if r.get("status") == "present")
    late = sum(1 for r in records if r.get("status") == "late")
    absent = sum(1 for r in records if r.get("status") == "absent")
    return jsonify({
        "total": total,
        "present": present,
        "late": late,
        "absent": absent,
        "present_rate": round(present / total * 100, 1) if total else 0,
        "late_rate": round(late / total * 100, 1) if total else 0,
        "absent_rate": round(absent / total * 100, 1) if total else 0,
    })
