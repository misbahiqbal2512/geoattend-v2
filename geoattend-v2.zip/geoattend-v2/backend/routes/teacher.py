from datetime import datetime
from flask import Blueprint, jsonify

from auth import current_user_id, role_required
from database import find_many, get_all, insert, get_by_id, update, delete, find_one
from validators import json_body

teacher_bp = Blueprint("teacher", __name__)


@teacher_bp.get("/dashboard")
@role_required("teacher")
def dashboard():
    uid = current_user_id()
    courses = find_many("courses", teacher_id=uid)
    active_sessions = [s for s in find_many("sessions", teacher_id=uid) if s.get("status") == "active"]
    return jsonify({
        "courses": [_enrich_course(c) for c in courses],
        "active_sessions": [_enrich_session(s) for s in active_sessions],
        "total_courses": len(courses),
        "total_sessions_today": len([s for s in find_many("sessions", teacher_id=uid)
                                     if s.get("created_at", "")[:10] == datetime.utcnow().date().isoformat()]),
    })


@teacher_bp.get("/classrooms")
@role_required("teacher", "admin")
def classrooms():
    return jsonify(get_all("classrooms"))


@teacher_bp.post("/classrooms")
@role_required("teacher", "admin")
def create_classroom():
    data, error = json_body(["name", "building", "latitude", "longitude", "radius_meters"])
    if error:
        return jsonify(error), 400
    try:
        room = insert("classrooms", {
            "name": data["name"].strip(),
            "building": data["building"].strip(),
            "room_number": data.get("room_number", "").strip(),
            "latitude": float(data["latitude"]),
            "longitude": float(data["longitude"]),
            "radius_meters": float(data["radius_meters"]),
        })
    except ValueError:
        return jsonify({"error": "ValidationError", "message": "Latitude, longitude, and radius must be numeric"}), 400
    return jsonify({"message": "Classroom created", "classroom": room}), 201


@teacher_bp.post("/courses")
@role_required("teacher")
def create_course():
    data, error = json_body(["code", "title", "classroom_id", "schedule_day", "start_time", "end_time"])
    if error:
        return jsonify(error), 400
    course = insert("courses", {
        "code": data["code"].strip().upper(),
        "title": data["title"].strip(),
        "credit_hours": int(data.get("credit_hours", 3)),
        "teacher_id": current_user_id(),
        "classroom_id": int(data["classroom_id"]),
        "schedule_day": data["schedule_day"],
        "start_time": data["start_time"],
        "end_time": data["end_time"],
    })
    return jsonify({"message": "Course created", "course": course}), 201


@teacher_bp.post("/courses/<int:course_id>/enroll")
@role_required("teacher")
def enroll_student(course_id):
    data, error = json_body(["student_id"])
    if error:
        return jsonify(error), 400
    student_id = int(data["student_id"])
    student = get_by_id("users", student_id)
    if not student or student.get("role") != "student":
        return jsonify({"error": "NotFound", "message": "Student not found"}), 404
    # Check already enrolled
    from database import exists
    if exists("enrollments", student_id=student_id, course_id=course_id):
        return jsonify({"error": "ConflictError", "message": "Student already enrolled"}), 409
    enr = insert("enrollments", {"student_id": student_id, "course_id": course_id})
    return jsonify({"message": "Student enrolled", "enrollment": enr}), 201


@teacher_bp.delete("/courses/<int:course_id>/enroll/<int:student_id>")
@role_required("teacher")
def unenroll_student(course_id, student_id):
    enrollments = find_many("enrollments", student_id=student_id, course_id=course_id)
    if not enrollments:
        return jsonify({"error": "NotFound", "message": "Enrollment not found"}), 404
    delete("enrollments", enrollments[0]["id"])
    return jsonify({"message": "Student unenrolled"})


@teacher_bp.get("/courses/<int:course_id>/students")
@role_required("teacher")
def course_students(course_id):
    enrollments = find_many("enrollments", course_id=course_id)
    students = []
    for enr in enrollments:
        s = get_by_id("users", enr["student_id"])
        if s:
            students.append({k: v for k, v in s.items() if k != "password_hash"})
    return jsonify(students)


# ─── Session Management ───────────────────────────────────────────────────────

@teacher_bp.post("/sessions/start")
@role_required("teacher")
def start_session():
    data, error = json_body(["course_id"])
    if error:
        return jsonify(error), 400
    uid = current_user_id()
    course_id = int(data["course_id"])
    course = get_by_id("courses", course_id)
    if not course or course.get("teacher_id") != uid:
        return jsonify({"error": "Forbidden", "message": "Not your course"}), 403

    # Check no active session for this course
    active = [s for s in find_many("sessions", course_id=course_id) if s.get("status") == "active"]
    if active:
        return jsonify({"error": "ConflictError", "message": "Session already active for this course",
                        "session": _enrich_session(active[0])}), 409

    classroom = get_by_id("classrooms", course["classroom_id"])
    session = insert("sessions", {
        "course_id": course_id,
        "teacher_id": uid,
        "classroom_id": course["classroom_id"],
        "status": "active",
        "started_at": datetime.utcnow().isoformat(),
        "ended_at": None,
        "late_after_minutes": int(data.get("late_after_minutes", 15)),
        "absent_after_minutes": int(data.get("absent_after_minutes", 30)),
    })
    return jsonify({"message": "Session started", "session": _enrich_session(session)}), 201


@teacher_bp.post("/sessions/<int:session_id>/end")
@role_required("teacher")
def end_session(session_id):
    uid = current_user_id()
    session = get_by_id("sessions", session_id)
    if not session or session.get("teacher_id") != uid:
        return jsonify({"error": "Forbidden", "message": "Not your session"}), 403

    # Mark absent all enrolled students who didn't attend
    course_id = session["course_id"]
    enrollments = find_many("enrollments", course_id=course_id)
    attended_ids = {r["student_id"] for r in find_many("attendance", session_id=session_id)}
    now = datetime.utcnow().isoformat()
    for enr in enrollments:
        sid = enr["student_id"]
        if sid not in attended_ids:
            insert("attendance", {
                "student_id": sid,
                "course_id": course_id,
                "session_id": session_id,
                "attendance_date": now[:10],
                "timestamp": now,
                "status": "absent",
                "latitude": None,
                "longitude": None,
                "accuracy_meters": None,
                "distance_meters": None,
            })

    updated = update("sessions", session_id, {"status": "ended", "ended_at": now})
    return jsonify({"message": "Session ended", "session": updated})


@teacher_bp.get("/sessions/<int:session_id>/live")
@role_required("teacher")
def session_live(session_id):
    """Real-time snapshot for teacher dashboard."""
    uid = current_user_id()
    session = get_by_id("sessions", session_id)
    if not session or session.get("teacher_id") != uid:
        return jsonify({"error": "Forbidden"}), 403

    course_id = session["course_id"]
    enrollments = find_many("enrollments", course_id=course_id)
    attendance_records = find_many("attendance", session_id=session_id)
    attended_ids = {r["student_id"]: r for r in attendance_records}

    present_list, late_list, absent_list, waiting_list = [], [], [], []
    for enr in enrollments:
        s = get_by_id("users", enr["student_id"])
        if not s:
            continue
        info = {"id": s["id"], "name": s["name"], "reg": s.get("registration_no", "")}
        if enr["student_id"] in attended_ids:
            rec = attended_ids[enr["student_id"]]
            info["status"] = rec["status"]
            info["timestamp"] = rec.get("timestamp", "")
            info["distance"] = rec.get("distance_meters", 0)
            if rec["status"] == "present":
                present_list.append(info)
            elif rec["status"] == "late":
                late_list.append(info)
            else:
                absent_list.append(info)
        else:
            waiting_list.append(info)

    live_locs = find_many("live_locations", session_id=session_id)

    return jsonify({
        "session": _enrich_session(session),
        "present": present_list,
        "late": late_list,
        "absent": absent_list,
        "waiting": waiting_list,
        "live_locations": live_locs,
        "counts": {
            "present": len(present_list),
            "late": len(late_list),
            "absent": len(absent_list),
            "waiting": len(waiting_list),
            "total": len(enrollments),
        },
    })


@teacher_bp.get("/sessions")
@role_required("teacher")
def my_sessions():
    uid = current_user_id()
    sessions = find_many("sessions", teacher_id=uid)
    return jsonify([_enrich_session(s) for s in sorted(sessions, key=lambda x: x.get("started_at", ""), reverse=True)])


@teacher_bp.get("/analytics")
@role_required("teacher")
def analytics():
    uid = current_user_id()
    courses = find_many("courses", teacher_id=uid)
    result = []
    for c in courses:
        sessions = find_many("sessions", course_id=c["id"])
        records = find_many("attendance", course_id=c["id"])
        total = len(records)
        present = sum(1 for r in records if r.get("status") == "present")
        late = sum(1 for r in records if r.get("status") == "late")
        absent = sum(1 for r in records if r.get("status") == "absent")
        result.append({
            **c,
            "session_count": len(sessions),
            "total_records": total,
            "present": present,
            "late": late,
            "absent": absent,
            "attendance_rate": round((present + late) / total * 100, 1) if total else 0,
        })
    return jsonify(result)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _enrich_course(course: dict) -> dict:
    classroom = get_by_id("classrooms", course.get("classroom_id"))
    enrollments = find_many("enrollments", course_id=course["id"])
    return {**course, "classroom": classroom, "enrolled_count": len(enrollments)}


def _enrich_session(session: dict) -> dict:
    course = get_by_id("courses", session.get("course_id"))
    classroom = get_by_id("classrooms", session.get("classroom_id"))
    return {**session, "course": course, "classroom": classroom}
