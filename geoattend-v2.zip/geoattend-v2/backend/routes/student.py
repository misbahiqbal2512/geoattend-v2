from flask import Blueprint, jsonify

from auth import current_user_id, role_required
from database import find_many, get_by_id, get_all

student_bp = Blueprint("student", __name__)


@student_bp.get("/dashboard")
@role_required("student")
def dashboard():
    uid = current_user_id()
    student = get_by_id("users", uid)
    enrollments = find_many("enrollments", student_id=uid)
    courses = []
    for enr in enrollments:
        c = get_by_id("courses", enr["course_id"])
        if c:
            classroom = get_by_id("classrooms", c.get("classroom_id"))
            courses.append({**c, "classroom": classroom})

    records = find_many("attendance", student_id=uid)
    total = len(records)
    present = sum(1 for r in records if r.get("status") == "present")
    late = sum(1 for r in records if r.get("status") == "late")
    absent = sum(1 for r in records if r.get("status") == "absent")
    pct = round((present + late) / total * 100, 1) if total else 0

    recent = sorted(records, key=lambda r: r.get("timestamp", r.get("attendance_date", "")), reverse=True)[:10]
    recent_with_course = [{**r, "course": get_by_id("courses", r["course_id"])} for r in recent]

    # Active sessions for enrolled courses
    active_sessions = []
    course_ids = {enr["course_id"] for enr in enrollments}
    for s in get_all("sessions"):
        if s.get("status") == "active" and s.get("course_id") in course_ids:
            course = get_by_id("courses", s["course_id"])
            classroom = get_by_id("classrooms", s.get("classroom_id"))
            active_sessions.append({**s, "course": course, "classroom": classroom})

    return jsonify({
        "student": _safe(student or {}),
        "courses": courses,
        "active_sessions": active_sessions,
        "analytics": {
            "overall_percentage": pct,
            "total_classes": total,
            "present": present,
            "late": late,
            "absent": absent,
            "recent": recent_with_course,
        },
    })


@student_bp.get("/profile")
@role_required("student")
def profile():
    user = get_by_id("users", current_user_id())
    return jsonify(_safe(user or {}))


@student_bp.get("/active-sessions")
@role_required("student")
def active_sessions():
    uid = current_user_id()
    enrollments = find_many("enrollments", student_id=uid)
    course_ids = {enr["course_id"] for enr in enrollments}
    sessions = []
    for s in get_all("sessions"):
        if s.get("status") == "active" and s.get("course_id") in course_ids:
            course = get_by_id("courses", s["course_id"])
            classroom = get_by_id("classrooms", s.get("classroom_id"))
            already_marked = bool(find_many("attendance", student_id=uid, session_id=s["id"]))
            sessions.append({**s, "course": course, "classroom": classroom, "already_marked": already_marked})
    return jsonify(sessions)


def _safe(user: dict) -> dict:
    return {k: v for k, v in user.items() if k != "password_hash"}
