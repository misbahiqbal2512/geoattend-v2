import logging
from flask import Blueprint, jsonify

from auth import create_token, hash_password, verify_password
from database import exists, find_one, insert
from validators import is_valid_email, json_body, validate_password

logger = logging.getLogger(__name__)
auth_bp = Blueprint("auth", __name__)

ALLOWED_ROLES = {"student", "teacher", "admin"}


# ─── Registration ──────────────────────────────────────────────────────────────

@auth_bp.post("/register/student")
def register_student():
    """Register a new student account."""
    data, error = json_body(["registration_no", "name", "email", "password", "department", "semester"])
    if error:
        logger.warning("Registration validation failed: %s", error)
        return jsonify(error), 400

    email = data["email"].strip().lower()
    if not is_valid_email(email):
        return jsonify({"error": "ValidationError", "message": "Invalid email address"}), 400

    pw_error = validate_password(data["password"])
    if pw_error:
        return jsonify({"error": "ValidationError", "message": pw_error}), 400

    if exists("users", email=email):
        return jsonify({"error": "ConflictError", "message": "An account with this email already exists"}), 409

    if exists("users", registration_no=data["registration_no"].strip()):
        return jsonify({"error": "ConflictError", "message": "Registration number already in use"}), 409

    try:
        semester = int(data["semester"])
        if not (1 <= semester <= 12):
            raise ValueError()
    except (ValueError, TypeError):
        return jsonify({"error": "ValidationError", "message": "Semester must be a number between 1 and 12"}), 400

    user = insert("users", {
        "name": data["name"].strip(),
        "email": email,
        "password_hash": hash_password(data["password"]),
        "role": "student",
        "department": data["department"].strip(),
        "registration_no": data["registration_no"].strip(),
        "semester": semester,
        "phone": data.get("phone", "").strip() or None,
    })

    logger.info("Student registered: %s (id=%s)", email, user["id"])
    return jsonify({
        "message": "Student registered successfully",
        "user": _safe_user(user),
    }), 201


# ─── Login ─────────────────────────────────────────────────────────────────────

@auth_bp.post("/login")
def login():
    """Authenticate any role and return a JWT."""
    data, error = json_body(["email", "password", "role"])
    if error:
        logger.warning("Login validation failed: %s", error)
        return jsonify(error), 400

    role = data["role"].strip().lower()
    if role not in ALLOWED_ROLES:
        return jsonify({
            "error": "ValidationError",
            "message": f"Role must be one of: {', '.join(sorted(ALLOWED_ROLES))}",
        }), 400

    email = data["email"].strip().lower()
    logger.info("Login attempt: email=%s role=%s", email, role)

    user = find_one("users", email=email)

    if user is None:
        logger.warning("Login failed: no user found for email=%s", email)
        return jsonify({"error": "AuthError", "message": "Invalid email or password"}), 401

    if user.get("role") != role:
        logger.warning(
            "Login failed: role mismatch for email=%s (stored=%s requested=%s)",
            email, user.get("role"), role,
        )
        return jsonify({
            "error": "AuthError",
            "message": f"This account is not registered as a {role}",
        }), 401

    if not verify_password(data["password"], user.get("password_hash", "")):
        logger.warning("Login failed: wrong password for email=%s", email)
        return jsonify({"error": "AuthError", "message": "Invalid email or password"}), 401

    token = create_token(user["id"], role)
    logger.info("Login success: email=%s role=%s id=%s", email, role, user["id"])

    return jsonify({
        "access_token": token,
        "role": role,
        "user": _safe_user(user),
    }), 200


# ─── Helpers ───────────────────────────────────────────────────────────────────

def _safe_user(user: dict) -> dict:
    """Return user dict without password_hash."""
    return {k: v for k, v in user.items() if k != "password_hash"}
