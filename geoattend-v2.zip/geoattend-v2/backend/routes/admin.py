from flask import Blueprint, jsonify

from auth import hash_password, role_required
from database import delete, find_many, get_all, insert, count, get_by_id, update
from validators import is_valid_email, json_body, validate_password

admin_bp = Blueprint("admin", __name__)


@admin_bp.get("/dashboard")
@role_required("admin")
def dashboard():
    all_users = get_all("users")
    records = get_all("attendance")
    sessions = get_all("sessions")
    total = len(records)
    present = sum(1 for r in records if r.get("status") == "present")
    late = sum(1 for r in records if r.get("status") == "late")
    return jsonify({
        "students": sum(1 for u in all_users if u.get("role") == "student"),
        "teachers": sum(1 for u in all_users if u.get("role") == "teacher"),
        "courses": count("courses"),
        "classrooms": count("classrooms"),
        "attendance_records": total,
        "active_sessions": sum(1 for s in sessions if s.get("status") == "active"),
        "total_sessions": len(sessions),
        "present_rate": round(present / total * 100, 1) if total else 0,
        "late_rate": round(sum(1 for r in records if r.get("status") == "late") / total * 100, 1) if total else 0,
        "absent_rate": round(sum(1 for r in records if r.get("status") == "absent") / total * 100, 1) if total else 0,
    })


@admin_bp.get("/students")
@role_required("admin", "teacher")
def students():
    users = [u for u in get_all("users") if u.get("role") == "student"]
    return jsonify([_safe(u) for u in sorted(users, key=lambda u: u.get("name", ""))])


@admin_bp.post("/students")
@role_required("admin")
def create_student():
    data, error = json_body(["registration_no", "name", "email", "password", "department", "semester"])
    if error:
        return jsonify(error), 400
    email = data["email"].strip().lower()
    if not is_valid_email(email):
        return jsonify({"error": "ValidationError", "message": "Invalid email"}), 400
    pw_err = validate_password(data["password"])
    if pw_err:
        return jsonify({"error": "ValidationError", "message": pw_err}), 400
    from database import exists
    if exists("users", email=email):
        return jsonify({"error": "ConflictError", "message": "Email already in use"}), 409
    student = insert("users", {
        "name": data["name"].strip(),
        "email": email,
        "password_hash": hash_password(data["password"]),
        "role": "student",
        "department": data["department"].strip(),
        "registration_no": data["registration_no"].strip(),
        "semester": int(data["semester"]),
        "phone": data.get("phone", "").strip() or None,
    })
    return jsonify({"message": "Student created", "student": _safe(student)}), 201


@admin_bp.delete("/students/<int:student_id>")
@role_required("admin")
def delete_student(student_id):
    ok = delete("users", student_id)
    if not ok:
        return jsonify({"error": "NotFound", "message": "Student not found"}), 404
    return jsonify({"message": "Student deleted"})


@admin_bp.get("/teachers")
@role_required("admin")
def teachers():
    users = [u for u in get_all("users") if u.get("role") == "teacher"]
    return jsonify([_safe(u) for u in sorted(users, key=lambda u: u.get("name", ""))])


@admin_bp.post("/teachers")
@role_required("admin")
def create_teacher():
    data, error = json_body(["employee_no", "name", "email", "password", "department"])
    if error:
        return jsonify(error), 400
    email = data["email"].strip().lower()
    if not is_valid_email(email):
        return jsonify({"error": "ValidationError", "message": "Invalid email address"}), 400
    pw_err = validate_password(data["password"])
    if pw_err:
        return jsonify({"error": "ValidationError", "message": pw_err}), 400
    from database import exists
    if exists("users", email=email):
        return jsonify({"error": "ConflictError", "message": "Email already in use"}), 409
    teacher = insert("users", {
        "name": data["name"].strip(),
        "email": email,
        "password_hash": hash_password(data["password"]),
        "role": "teacher",
        "department": data["department"].strip(),
        "employee_no": data["employee_no"].strip(),
    })
    return jsonify({"message": "Teacher created", "teacher": _safe(teacher)}), 201


@admin_bp.delete("/teachers/<int:teacher_id>")
@role_required("admin")
def delete_teacher(teacher_id):
    ok = delete("users", teacher_id)
    if not ok:
        return jsonify({"error": "NotFound", "message": "Teacher not found"}), 404
    return jsonify({"message": "Teacher deleted"})


@admin_bp.get("/attendance")
@role_required("admin")
def all_attendance():
    records = get_all("attendance")
    result = []
    for r in records:
        student = get_by_id("users", r.get("student_id"))
        course = get_by_id("courses", r.get("course_id"))
        result.append({
            **r,
            "student_name": student.get("name", "") if student else "",
            "student_reg": student.get("registration_no", "") if student else "",
            "course_title": course.get("title", "") if course else "",
            "course_code": course.get("code", "") if course else "",
        })
    return jsonify(sorted(result, key=lambda x: x.get("timestamp", ""), reverse=True))


@admin_bp.delete("/attendance/<int:att_id>")
@role_required("admin")
def delete_attendance(att_id):
    ok = delete("attendance", att_id)
    if not ok:
        return jsonify({"error": "NotFound", "message": "Record not found"}), 404
    return jsonify({"message": "Attendance record deleted"})


@admin_bp.get("/analytics")
@role_required("admin")
def analytics():
    records = get_all("attendance")
    users = get_all("users")
    students = [u for u in users if u.get("role") == "student"]
    # Per-student stats
    student_stats = []
    for s in students:
        recs = [r for r in records if r.get("student_id") == s["id"]]
        total = len(recs)
        present = sum(1 for r in recs if r.get("status") == "present")
        late = sum(1 for r in recs if r.get("status") == "late")
        student_stats.append({
            "id": s["id"],
            "name": s["name"],
            "reg": s.get("registration_no", ""),
            "department": s.get("department", ""),
            "total": total,
            "present": present,
            "late": late,
            "absent": total - present - late,
            "rate": round((present + late) / total * 100, 1) if total else 0,
        })
    student_stats.sort(key=lambda x: x["rate"], reverse=True)
    return jsonify({"student_stats": student_stats})


def _safe(user: dict) -> dict:
    return {k: v for k, v in user.items() if k != "password_hash"}
