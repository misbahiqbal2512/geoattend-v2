from flask import Blueprint, render_template, send_from_directory
import os

frontend_bp = Blueprint("frontend", __name__)


@frontend_bp.get("/")
def index():
    return render_template("index.html")


@frontend_bp.get("/manifest.json")
def manifest():
    return send_from_directory(os.path.join(os.path.dirname(__file__), "..", "static"), "manifest.json")


@frontend_bp.get("/sw.js")
def service_worker():
    return send_from_directory(os.path.join(os.path.dirname(__file__), "..", "static"), "sw.js",
                               mimetype="application/javascript")
