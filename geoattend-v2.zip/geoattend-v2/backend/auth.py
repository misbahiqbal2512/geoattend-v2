"""
Auth utilities: password hashing with werkzeug, JWT with PyJWT.
"""
import os
from datetime import datetime, timedelta, timezone
from functools import wraps

import jwt
from flask import current_app, jsonify, request
from werkzeug.security import check_password_hash, generate_password_hash

JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 8


def hash_password(password: str) -> str:
    """Hash a plain-text password using werkzeug pbkdf2."""
    return generate_password_hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    """Compare a plain-text password against its stored hash."""
    return check_password_hash(hashed, plain)


def create_token(user_id: int, role: str) -> str:
    secret = current_app.config["JWT_SECRET_KEY"]
    payload = {
        "sub": str(user_id),
        "role": role,
        "iat": datetime.now(tz=timezone.utc),
        "exp": datetime.now(tz=timezone.utc) + timedelta(hours=JWT_EXPIRY_HOURS),
    }
    return jwt.encode(payload, secret, algorithm=JWT_ALGORITHM)


def decode_token(token: str) -> dict | None:
    secret = current_app.config["JWT_SECRET_KEY"]
    try:
        return jwt.decode(token, secret, algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


def get_current_user() -> dict | None:
    """Extract and decode the Bearer token from the current request."""
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None
    token = auth[7:]
    return decode_token(token)


def login_required(fn):
    """Decorator: any authenticated user."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        payload = get_current_user()
        if payload is None:
            return jsonify({"error": "Unauthorized", "message": "Valid token required"}), 401
        return fn(*args, **kwargs)
    return wrapper


def role_required(*roles):
    """Decorator: authenticated user whose role is in the allowed set."""
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            payload = get_current_user()
            if payload is None:
                return jsonify({"error": "Unauthorized", "message": "Valid token required"}), 401
            if payload.get("role") not in roles:
                return jsonify({"error": "Forbidden", "message": f"Requires role: {', '.join(roles)}"}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def current_user_id() -> int:
    payload = get_current_user()
    if payload:
        return int(payload["sub"])
    raise RuntimeError("No authenticated user")


def current_role() -> str:
    payload = get_current_user()
    if payload:
        return payload["role"]
    raise RuntimeError("No authenticated user")
