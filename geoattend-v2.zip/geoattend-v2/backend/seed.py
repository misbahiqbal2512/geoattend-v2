"""
Seed initial demo data into JSON files.
Run: python seed.py
"""
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from database import exists, insert, find_one, find_many, get_all
from auth import hash_password
from datetime import date, timedelta, datetime


def seed():
    # ── Admin ──────────────────────────────────────────────────────────────
    if not exists("users", email="admin@geoattend.local"):
        insert("users", {
            "name": "System Admin",
            "email": "admin@geoattend.local",
            "password_hash": hash_password("Admin@12345"),
            "role": "admin",
            "department": "Administration",
        })
        print("Admin created  ->  admin@geoattend.local / Admin@12345")
    else:
        print("Admin already exists")

    # ── Teacher ────────────────────────────────────────────────────────────
    if not exists("users", email="teacher@geoattend.local"):
        insert("users", {
            "name": "Dr. Ayesha Khan",
            "email": "teacher@geoattend.local",
            "password_hash": hash_password("Teacher@12345"),
            "role": "teacher",
            "department": "Computer Science",
            "employee_no": "T-1001",
        })
        print("Teacher created ->  teacher@geoattend.local / Teacher@12345")
    else:
        print("Teacher already exists")
    teacher = find_one("users", email="teacher@geoattend.local")

    # ── Students ───────────────────────────────────────────────────────────
    students_data = [
        ("Ali Raza", "student@geoattend.local", "Student@12345", "CS-2026-001", 7, "+923001234567"),
        ("Sara Ahmed", "sara@geoattend.local", "Student@12345", "CS-2026-002", 7, "+923001234568"),
        ("Ahmed Bilal", "ahmed@geoattend.local", "Student@12345", "CS-2026-003", 7, "+923001234569"),
        ("Fatima Noor", "fatima@geoattend.local", "Student@12345", "CS-2026-004", 7, "+923001234570"),
        ("Usman Tariq", "usman@geoattend.local", "Student@12345", "CS-2026-005", 7, "+923001234571"),
    ]
    students = []
    for name, email, pw, reg, sem, phone in students_data:
        if not exists("users", email=email):
            s = insert("users", {
                "name": name,
                "email": email,
                "password_hash": hash_password(pw),
                "role": "student",
                "department": "Computer Science",
                "registration_no": reg,
                "semester": sem,
                "phone": phone,
            })
            print(f"Student created -> {email} / {pw}")
        else:
            s = find_one("users", email=email)
            print(f"Student already exists ({email})")
        students.append(s)

    # ── Classrooms ────────────────────────────────────────────────────────
    if not exists("classrooms", name="CS Lab 1"):
        room1 = insert("classrooms", {
            "name": "CS Lab 1",
            "building": "Main Block",
            "room_number": "101",
            "latitude": 31.5204000,
            "longitude": 74.3587000,
            "radius_meters": 50,
        })
        print("Classroom 'CS Lab 1' created")
    else:
        room1 = find_one("classrooms", name="CS Lab 1")

    if not exists("classrooms", name="Lecture Hall A"):
        room2 = insert("classrooms", {
            "name": "Lecture Hall A",
            "building": "Academic Block",
            "room_number": "204",
            "latitude": 31.5215000,
            "longitude": 74.3601000,
            "radius_meters": 40,
        })
        print("Classroom 'Lecture Hall A' created")
    else:
        room2 = find_one("classrooms", name="Lecture Hall A")

    # ── Courses ────────────────────────────────────────────────────────────
    if not exists("courses", code="CS-471"):
        course1 = insert("courses", {
            "code": "CS-471",
            "title": "Artificial Intelligence",
            "credit_hours": 3,
            "teacher_id": teacher["id"],
            "classroom_id": room1["id"],
            "schedule_day": "Monday",
            "start_time": "09:00",
            "end_time": "10:30",
        })
        print("Course CS-471 created")
    else:
        course1 = find_one("courses", code="CS-471")

    if not exists("courses", code="CS-415"):
        course2 = insert("courses", {
            "code": "CS-415",
            "title": "Distributed Systems",
            "credit_hours": 3,
            "teacher_id": teacher["id"],
            "classroom_id": room2["id"],
            "schedule_day": "Wednesday",
            "start_time": "11:00",
            "end_time": "12:30",
        })
        print("Course CS-415 created")
    else:
        course2 = find_one("courses", code="CS-415")

    # ── Enrollments ────────────────────────────────────────────────────────
    for s in students:
        if not find_many("enrollments", student_id=s["id"], course_id=course1["id"]):
            insert("enrollments", {"student_id": s["id"], "course_id": course1["id"]})
        if not find_many("enrollments", student_id=s["id"], course_id=course2["id"]):
            insert("enrollments", {"student_id": s["id"], "course_id": course2["id"]})
    print(f"Enrolled {len(students)} students in CS-471 and CS-415")

    # ── Historical sessions + attendance (for analytics demo) ──────────────
    existing_sessions = get_all("sessions")
    if len(existing_sessions) < 6:
        today = date.today()
        # Create 6 past (ended) sessions across the last 2 weeks
        for day_offset in range(14, 0, -2):
            session_date = today - timedelta(days=day_offset)
            started_at = datetime.combine(session_date, datetime.min.time()).replace(hour=9, minute=0)
            session = insert("sessions", {
                "course_id": course1["id"],
                "teacher_id": teacher["id"],
                "classroom_id": room1["id"],
                "status": "ended",
                "started_at": started_at.isoformat(),
                "ended_at": (started_at + timedelta(minutes=40)).isoformat(),
                "late_after_minutes": 15,
                "absent_after_minutes": 30,
            })
            # Simulate varied attendance behaviour per student
            for idx, s in enumerate(students):
                roll = (idx + day_offset) % 5
                if roll == 0:
                    status, minutes_in, dist = "absent", None, None
                elif roll in (1, 2):
                    status, minutes_in, dist = "present", 5 + idx, 8 + idx * 3
                else:
                    status, minutes_in, dist = "late", 18 + idx, 12 + idx * 2

                if status == "absent":
                    insert("attendance", {
                        "student_id": s["id"],
                        "course_id": course1["id"],
                        "session_id": session["id"],
                        "attendance_date": session_date.isoformat(),
                        "timestamp": (started_at + timedelta(minutes=35)).isoformat(),
                        "status": "absent",
                        "latitude": None,
                        "longitude": None,
                        "accuracy_meters": None,
                        "distance_meters": None,
                    })
                else:
                    insert("attendance", {
                        "student_id": s["id"],
                        "course_id": course1["id"],
                        "session_id": session["id"],
                        "attendance_date": session_date.isoformat(),
                        "timestamp": (started_at + timedelta(minutes=minutes_in)).isoformat(),
                        "status": status,
                        "latitude": room1["latitude"] + 0.0001,
                        "longitude": room1["longitude"] + 0.0001,
                        "accuracy_meters": 12,
                        "distance_meters": dist,
                    })
        print("Seeded 6 historical sessions with attendance records")
    else:
        print("Historical sessions already exist")

    print("\nSeed complete.")
    print("\n--- Demo Login Credentials ---")
    print("Admin   : admin@geoattend.local / Admin@12345")
    print("Teacher : teacher@geoattend.local / Teacher@12345")
    print("Student : student@geoattend.local / Student@12345")
    print("(More students: sara@, ahmed@, fatima@, usman@ @geoattend.local / Student@12345)")


if __name__ == "__main__":
    seed()
