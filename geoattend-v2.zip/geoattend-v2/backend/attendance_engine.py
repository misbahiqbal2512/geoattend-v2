"""
Core geofence attendance engine.
Called by Socket.IO location_update events.
"""
import math
from datetime import datetime, timezone

from database import find_many, get_by_id, insert, update, get_all


def haversine(lat1, lon1, lat2, lon2) -> float:
    R = 6_371_000
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def get_active_sessions() -> list[dict]:
    return [s for s in get_all("sessions") if s.get("status") == "active"]


def compute_status(session_start_iso: str, now_iso: str, late_after_minutes: int = 15) -> str:
    """
    Present if within `late_after_minutes` of session start, otherwise Late.

    IMPORTANT: A student who physically enters the classroom is NEVER
    auto-marked "Absent" here, no matter how late they arrive — they showed
    up, so at worst they are "Late". "Absent" is reserved exclusively for
    students who never enter the geofence at all before the teacher ends
    the session (handled in routes/teacher.py end_session()).
    """
    try:
        start = datetime.fromisoformat(session_start_iso.replace("Z", "+00:00"))
        now = datetime.fromisoformat(now_iso.replace("Z", "+00:00"))
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)
        diff_minutes = (now - start).total_seconds() / 60
        if diff_minutes <= late_after_minutes:
            return "present"
        else:
            return "late"
    except Exception:
        return "present"


def process_location_update(student_id: int, lat: float, lon: float, accuracy: float, socketio):
    """
    Check all active sessions for this student.
    If within radius and not already marked → mark attendance and emit real-time event.
    """
    now = datetime.utcnow().isoformat()
    active_sessions = get_active_sessions()

    for session in active_sessions:
        session_id = session["id"]
        course_id = session["course_id"]

        # Check student is enrolled
        enrollment = find_many("enrollments", student_id=student_id, course_id=course_id)
        if not enrollment:
            continue

        # Check not already marked for this session
        existing = find_many("attendance", student_id=student_id, session_id=session_id)
        if existing:
            # Update their last-known location for map display
            _update_student_location(student_id, session_id, lat, lon, accuracy, "already_marked")
            continue

        # Get classroom coords
        classroom = get_by_id("classrooms", session["classroom_id"])
        if not classroom:
            continue

        distance = haversine(lat, lon, classroom["latitude"], classroom["longitude"])
        max_radius = float(classroom.get("radius_meters", 50))

        # Update live location regardless (for map)
        _update_student_location(student_id, session_id, lat, lon, accuracy, "outside" if distance > max_radius else "inside")

        # Emit live location to teacher room
        student = get_by_id("users", student_id)
        socketio.emit("student_location", {
            "student_id": student_id,
            "student_name": student.get("name", "Unknown") if student else "Unknown",
            "lat": lat,
            "lon": lon,
            "distance": round(distance, 1),
            "inside": distance <= max_radius,
            "session_id": session_id,
        }, room=f"session_{session_id}")

        if distance <= max_radius and accuracy <= 150:
            # Mark attendance
            status = compute_status(session.get("started_at", now), now, session.get("late_after_minutes", 15))
            record = insert("attendance", {
                "student_id": student_id,
                "course_id": course_id,
                "session_id": session_id,
                "attendance_date": now[:10],
                "timestamp": now,
                "status": status,
                "latitude": lat,
                "longitude": lon,
                "accuracy_meters": accuracy,
                "distance_meters": round(distance, 2),
            })

            student = get_by_id("users", student_id)
            course = get_by_id("courses", course_id)

            # Emit to teacher's session room
            socketio.emit("attendance_marked", {
                "record": record,
                "student_name": student.get("name", "Unknown") if student else "Unknown",
                "student_reg": student.get("registration_no", "") if student else "",
                "course_title": course.get("title", "") if course else "",
                "status": status,
                "session_id": session_id,
                "timestamp": now,
                "distance": round(distance, 1),
            }, room=f"session_{session_id}")

            # Notify the student
            socketio.emit("attendance_confirmed", {
                "status": status,
                "message": f"Attendance marked as {status.upper()}",
                "session_id": session_id,
                "distance": round(distance, 1),
            }, room=f"user_{student_id}")


def _update_student_location(student_id, session_id, lat, lon, accuracy, inside_status):
    """Upsert live_locations table for map display."""
    from database import find_many as fm
    existing = fm("live_locations", student_id=student_id, session_id=session_id)
    data = {
        "student_id": student_id,
        "session_id": session_id,
        "lat": lat,
        "lon": lon,
        "accuracy": accuracy,
        "inside_status": inside_status,
        "last_seen": datetime.utcnow().isoformat(),
    }
    if existing:
        update("live_locations", existing[0]["id"], data)
    else:
        insert("live_locations", data)
