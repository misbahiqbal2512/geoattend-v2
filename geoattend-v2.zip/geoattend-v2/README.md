# GeoAttend — Smart GPS-Based Attendance System

GeoAttend is a real-time, GPS-based university attendance platform. Students never
press an "Attendance" button — when a teacher starts a session and a student's
phone/laptop comes within the classroom's geofence, attendance is marked
**automatically** and the teacher's dashboard updates **live** (Socket.IO),
complete with a live map showing each student as a green (inside) or red
(outside) marker.

This document covers: what changed from the original codebase, the new
architecture, how to run it locally, and how to deploy it for real students to use.

---

## 1. Analysis of the Original Codebase

The original `geoattend-fixed` project was a solid foundation: Flask blueprints,
JWT auth, a JSON-file database, and a manual "Mark Attendance" button that
checked GPS distance via Haversine on click. However, several issues made it
unsuitable for the "automatic attendance" concept requested:

| # | Weakness in the original code | Impact |
|---|---|---|
| 1 | **Manual `/api/attendance/mark` endpoint** — student had to click a button | Defeats the entire "automatic attendance" objective |
| 2 | **No session concept** — attendance was just `(student, course, date)` | Couldn't distinguish "today's lecture" from any other time, no Present/Late/Absent timing logic |
| 3 | **No real-time layer** — teacher had no live view at all | No "live feed", no instant updates |
| 4 | **`student.py` had dead/duplicate code** — `find_one_by_id` redefined inline, an unused `_email_by_id` stub, a redundant double-lookup of the same user | Confusing, error-prone |
| 5 | **No live map / location broadcasting** | Couldn't visualize who is inside vs outside the geofence |
| 6 | **Weak password policy** (6 chars, no complexity) | Security weakness for an admin-managed account system |
| 7 | **No PWA support** — no manifest, service worker, or icons | Couldn't be "installed" on a phone/laptop as requested |
| 8 | **Old multi-page templates** (`login.html`, `student_dashboard.html`, etc.) were unused leftovers alongside a half-built `app.js`/`style.css` SPA | Dead code, confusing structure |
| 9 | **No deployment configuration** (Procfile, gunicorn, etc.) | Couldn't be hosted anywhere but localhost |
| 10 | **`live_locations` / `sessions` tables didn't exist** | No way to track who is currently in range |

---

## 2. What Was Built (New System)

### Core Concept Change: Session-Based Automatic Attendance

- A **Course** is linked to a **Classroom** (GPS coordinates + radius).
- A **Teacher** clicks **Start Session** → creates an active `Session` row.
- Every logged-in **Student**'s browser silently runs
  `navigator.geolocation.watchPosition()` and streams `{lat, lon, accuracy}`
  to the server every few seconds over **Socket.IO** — no button, no page
  refresh.
- The server's `attendance_engine.py`:
  1. Finds all **active sessions** for courses the student is enrolled in.
  2. Computes distance via the **Haversine formula**.
  3. If `distance <= radius_meters` **and** the student hasn't been marked
     yet for this session → **inserts an attendance record automatically**.
  4. Computes **Present / Late / Absent** from elapsed time since
     `session.started_at` (0–15 min = Present, 15–30 min = Late, >30 min,
     or never arrived by session end = Absent).
  5. Emits `attendance_marked` to the teacher's dashboard room and
     `attendance_confirmed` to the student — both update **instantly**,
     no polling required.
- The teacher's **Live Classroom Map** (Leaflet/OpenStreetMap) plots the
  classroom geofence circle plus a live marker per student: **green = inside
  radius**, **red = outside**. Markers move in real time as
  `student_location` events arrive.
- **Ending a session** auto-marks every enrolled student who never appeared
  as **Absent**.

### New / Rewritten Backend Modules

```
backend/
├── app.py                 — Flask + Socket.IO app factory & socket event handlers
├── attendance_engine.py   — NEW: Haversine geofence + auto status engine
├── auth.py                — JWT auth (unchanged logic, reused)
├── database.py            — JSON file DB (thread-safe, reused & cleaned)
├── validators.py          — Stronger password policy (8+ chars, upper, digit)
├── seed.py                — Rebuilt: 5 students, 2 courses, 2 classrooms,
│                              6 historical sessions w/ varied attendance for analytics
├── wsgi.py                — NEW: gunicorn/eventlet production entrypoint
├── routes/
│   ├── auth.py            — login / register (reused)
│   ├── admin.py           — dashboard, CRUD students/teachers, analytics, attendance log
│   ├── teacher.py         — REWRITTEN: classrooms, courses, enroll,
│   │                          start/end session, live session snapshot, analytics
│   ├── student.py         — REWRITTEN: dashboard, active sessions, profile
│   ├── attendance.py       — history, CSV export, per-session records, admin analytics
│   └── frontend.py        — serves SPA shell + manifest + service worker
```

### New Frontend (Complete Redesign)

A single-page application (`templates/index.html` + `static/js/app.js` +
`static/css/style.css`) replaces the old multi-page templates:

- **Dark, premium "SaaS" UI** — gradient brand colors, glass cards, animated
  stat counters, doughnut charts (Chart.js), progress bars, toast
  notifications, skeleton/empty states.
- **Role-based sidebar navigation** (Admin / Teacher / Student) with a live
  "active session" pulse indicator.
- **Admin**: dashboard KPIs, attendance-rate charts, student/teacher CRUD
  modals, attendance-rankings table, full attendance log.
- **Teacher**: course & classroom management (with "use my GPS location" for
  setting classroom coordinates), one-click **Start Session**, and the
  **Live Session Monitor** — present/late/absent/waiting counts, a live feed
  ("✓ Ali entered classroom at 08:58 AM"), and the live geofence map.
- **Student**: GPS status indicator in the top bar, attendance percentage
  ring, present/late/absent breakdown, recent activity feed, full history
  table, course list, profile.
- **Mobile responsive** — collapsible sidebar, responsive grids, touch-sized
  controls.

### PWA Support

- `static/manifest.json` — installable app metadata (name, icons, theme).
- `static/sw.js` — service worker caching the app shell (CSS/JS/manifest)
  for fast loads; **never caches `/api/*` or `/socket.io/*`** so live data
  stays fresh.
- `static/icon-192.png` / `icon-512.png` — generated app icons.
- The login screen shows an **"Install App"** banner using the
  `beforeinstallprompt` event when the browser detects the PWA criteria are met.

### Security Hardening

- Password policy: minimum 8 characters, at least one uppercase letter and
  one digit (`validators.py`).
- **Duplicate attendance prevention**: a student can only be auto-marked
  **once per session** (`find_many("attendance", student_id=..., session_id=...)`
  guard in `attendance_engine.py`).
- **GPS accuracy gate**: locations reported with `accuracy > 150m` are
  ignored for marking (reduces low-accuracy false positives).
- **Session-scoped marking**: attendance can only be created while a session
  `status == "active"` — there is no endpoint for a student to insert an
  attendance row directly. All attendance writes for the geofence flow
  happen server-side, driven only by the authenticated student's own
  Socket.IO connection (JWT-verified on connect).
- Socket.IO connections are **rejected without a valid JWT**
  (`on_connect` handler in `app.py`).

---

## 3. Running Locally

```bash
cd backend
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # then edit SECRET_KEY / JWT_SECRET_KEY
python seed.py                     # creates demo admin/teacher/students + sample data
python app.py                      # runs on http://localhost:5000
```

Open `http://localhost:5000` in Chrome. Use the demo credential chips on the
login screen, or:

| Role    | Email                       | Password       |
|---------|-----------------------------|-----------------|
| Admin   | admin@geoattend.local       | Admin@12345     |
| Teacher | teacher@geoattend.local     | Teacher@12345   |
| Student | student@geoattend.local     | Student@12345   |
| Student | sara@geoattend.local        | Student@12345   |
| Student | ahmed@geoattend.local       | Student@12345   |
| Student | fatima@geoattend.local      | Student@12345   |
| Student | usman@geoattend.local       | Student@12345   |

### Demo Walkthrough (Single Machine)

1. Log in as **Teacher** → *Classrooms* → confirm "CS Lab 1" exists, or click
   **Use My Current Location** to set a classroom at your real GPS position
   (recommended for a live viva demo).
2. *My Courses* → **Start Session** on CS-471.
3. Open a second browser/incognito tab → log in as a **Student** enrolled in
   CS-471 (e.g. `student@geoattend.local`). Allow location permission when
   prompted.
4. Because the demo classroom is set to your real coordinates (if you used
   "Use My Current Location"), the student's browser is already inside the
   radius — within ~10 seconds the teacher's **Live Session** tab shows the
   student appear in the live feed as **Present**, with a **green marker** on
   the map, all without any button press.
5. Click **End Session** — any unmarked students are auto-marked **Absent**.

---

## 4. Real-Time Architecture

```
Student Browser                    Server (Flask + Socket.IO)              Teacher Browser
─────────────────                  ────────────────────────────            ────────────────
watchPosition() ──"location_update"──▶ attendance_engine.process_location_update()
                                          │
                                          ├─ Haversine distance check
                                          ├─ status = present/late/absent
                                          ├─ insert attendance record
                                          │
                  ◀──"attendance_confirmed"── emit to room user_<student_id>
                                          │
                                          └──"attendance_marked" / "student_location"──▶ room session_<id>
                                                                                          │
                                                                            Live feed + map update (no refresh)
```

- Rooms: `user_<id>` (personal notifications), `role_<role>`, and
  `session_<session_id>` (everyone watching a specific live session).
- Students join no special room — they just need a connected, authenticated
  socket. Teachers explicitly `join_session` when opening the Live Session view.

---

## 5. Deployment

The app is a **single Flask + Socket.IO service** (Flask serves the API, the
SPA, and the WebSocket endpoint together). This is the simplest and most
reliable way to run it with working real-time features — splitting the
static frontend onto Vercel and the API onto Render is possible but adds
CORS/WebSocket-proxying complexity that isn't needed here, since Flask
already serves the SPA.

### Recommended: Render (single service)

1. Push this repository to GitHub.
2. In Render, choose **New → Blueprint** and point it at the repo (it will
   read `render.yaml`).
3. Render will:
   - `pip install -r requirements.txt && python seed.py`
   - Start with `gunicorn -k eventlet -w 1 --timeout 120 wsgi:app`
   - Mount a **persistent disk** at `backend/data` so attendance/user data
     survives restarts and redeploys.
4. Render auto-generates `SECRET_KEY` and `JWT_SECRET_KEY` (see `render.yaml`).
5. Your app will be live at `https://geoattend.onrender.com` (or similar) —
   share this URL with students. They open it in Chrome, log in, and tap
   **Install App** to add it to their home screen. No source code, npm, or
   local setup required.

> **Note on the JSON database**: this project (like the original) stores data
> in JSON files for simplicity and zero external dependencies — perfect for a
> class/demo deployment. Render's free plan disks are persistent across
> deploys when configured as in `render.yaml`. If you later need true
> multi-instance scaling or want MongoDB Atlas, replace the functions in
> `database.py` (`get_all`, `find_one`, `insert`, `update`, `delete`, ...)
> with `pymongo` equivalents — every route calls only this module, so the
> rest of the app does not need to change.

### Alternative: Vercel + Render + MongoDB Atlas (advanced)

If you want the split architecture mentioned in the brief:

- **Backend (Render)**: deploy `backend/` exactly as above, but swap
  `database.py` for a MongoDB-backed version using **MongoDB Atlas** (a free
  cluster). Set `MONGODB_URI` as a Render environment variable.
- **Frontend (Vercel)**: the SPA in `templates/index.html` +
  `static/` is fully static once you set `API = "https://your-render-app.onrender.com"`
  at the top of `app.js` (instead of the empty string). Deploy
  `backend/templates` and `backend/static` as a static site on Vercel.
  Socket.IO will connect cross-origin to the Render backend (CORS is already
  wide-open via `Access-Control-Allow-Origin: *`).

This is **optional** — the single-service Render deployment above is fully
functional and is the recommended path for getting a working URL quickly.

---

## 6. Updated Project Structure

```
geoattend-v2/
├── render.yaml                  # Render Blueprint (single-service deploy)
├── .gitignore
├── README.md                    # this file
└── backend/
    ├── app.py                   # Flask + Socket.IO app factory, socket events
    ├── attendance_engine.py     # Haversine geofence engine + status calc
    ├── auth.py                  # JWT + password hashing
    ├── database.py              # JSON-file data layer
    ├── validators.py            # input validation
    ├── seed.py                  # demo data seeder
    ├── wsgi.py                  # gunicorn entrypoint
    ├── Procfile                 # gunicorn start command
    ├── runtime.txt              # Python version pin
    ├── requirements.txt
    ├── .env.example
    ├── data/                    # JSON "database" (seeded on first run)
    │   ├── users.json
    │   ├── classrooms.json
    │   ├── courses.json
    │   ├── enrollments.json
    │   ├── sessions.json
    │   ├── attendance.json
    │   └── live_locations.json
    ├── routes/
    │   ├── auth.py
    │   ├── admin.py
    │   ├── teacher.py
    │   ├── student.py
    │   ├── attendance.py
    │   └── frontend.py
    ├── templates/
    │   ├── index.html           # SPA shell
    │   └── 404.html
    └── static/
        ├── css/style.css
        ├── js/app.js
        ├── manifest.json
        ├── sw.js
        ├── icon-192.png
        └── icon-512.png
```

---

## 7. Attendance Status Rules (recap)

| Time since session start | Status   |
|---------------------------|----------|
| 0 – 15 minutes             | Present  |
| 15 – 30 minutes            | Late     |
| > 30 minutes, or never arrived by the time the teacher ends the session | Absent |

These thresholds are configurable per-session via `late_after_minutes` /
`absent_after_minutes` when calling `POST /api/teacher/sessions/start`.
